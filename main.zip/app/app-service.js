var __maAppData=__maAppData||{};
var __maRoute=__maRoute||"";
var __layer__='service';
var __maAppCode__=__maAppCode__||{};
var global=global||{};
var __MAML_GLOBAL__=__MAML_GLOBAL__||{entrys:{},defines:{},modules:{},sjs_init:false}; 
var Component=Component||function(){};
var __maI18nResource__=__maI18nResource__||{};
(function (i18nRes) {
  // Merge i18n resource in subpackage scenario
  var newI18nRes={"am-ET":{"lang":"አማ","greetings":"ሰላም","enter_fayda_no_text":"የፋይዳ ተለዋጭ ቁጥርዎን (FAN) ያስገቡ","next":"ይቀጥሉ","view_digital_id":"ዲጂታል መታወቂያዎን ይመልከቱ","card_information":"የካርድ መረጃ","logout":"ይውጡ","verified":"የተረጋገጠ","not_verified":"ያልተረጋገጠ","view_back_side":"ጀርባውን ይመልከቱ","view_front_side":"የፊቱን ይመልከቱ","we_could_not_find_your_id":"መታወቂያዎ ሊገኝ አልቻለም ፤ ","please_register":"ለመመዝገብ ይህንን ይጫኑ","register":"እዚህ ይመዝገቡ!","download":"ያውርዱ","view_full_size":"በትልቁ ይመልከቱ","alert_logout":"እርግጠኛ ነዎት ለመውጣት ይፈልጋሉ","yes":"አዎ","no":"አይ","sign_in_with_telebirr":"በቴሌብር ይግቡ","not_registered":"ለፋይዳ ዲጂታል መታወቂያ አልተመዘገቡም?","Verified":"ትክክለኛነቱ የተረጋገጠ","Not_verified":"ትክክለኛነቱ ያልተረጋገጠ","scan_qr_code_title":"አንድን መታወቂያ ለማረጋገጥ ኪው አር ኮድ ለማንሳት የሚለውን ይጫኑ","scan_qr_code":"ኪው አር ኮድ ያንሱ","done":"እሺ","Home":"የፊት ገጽ","Verify":"ማረጋገጥ","rid_required":"የምዝገባ ቁጥርዎ ያስፈልጋል!","please_scan_the_qr_code":"ኪው አር ኮድዎን ስካን ያድርጉ","enter_rid":"ወይም የምዝገባ ቁጥርዎን ያስገቡ","resend_fin":"ልዩ ቁጥርዎን ይላኩ","lost_fin":"ልዩ ቁጥርዎ አልተላከልዎትም?","444_resend":"የምዝገባ ቁጥሩ አልተገኘም","444_resend_content":"እባክዎ የደንበኞች አገልግሎትን (id.gov.et/help) ያግኙ","200_resend":"አጭር የጽሁፍ መልዕክቱ በስልክዎ ተልኳል።","200_resend_content":"ልዩ ቁጥርዎ በስልክዎ ተልኳል።","503_resend":"አገልግሎቱን ከሳምንት በኋላ እንደገና ማግኘት ይችላሉ ፤ እናመሰግናለን!","503_resend_content":"አገልግሎቱን ደግሞ ለማግኘት አንድ ሳምንት ይጠብቁ","error_resend":"አገልግሎቱ አሁን ማግኘት አልተቻለም ፣ እባክዎ ትንሽ ቆይተው ይሞክሩ","error_resend_content":"ኔትወርክ ላይ ችግር አለ","invalid_rid":"ትክክል ያልሆነ የምዝገባ ቁጥር","invalid_rid_content":"የምዝገባ ቁጥርዎን በትክክል ያስገቡ","season_expired_title":"ጊዜው አልፎበታል!","season_expired_description":"የእርስዎን ፒዲኤፍ ቅጂ ለማግኘት፣ እባክዎ ይውጡ እና እንደገና ይግቡ።","logout_text":"ይውጡ","cancel_text":"ይቅር","tooltip_info":"FIN የፋይዳ መለያ ቁጥር ነው እና FAN የፋይዳ ተለዋጭ  ቁጥር ነው፣ እነዚህ ሁለቱ በአጭር የጽሁፍ መልዕክት ውስጥ በብሄራዊ መታወቂያ በሚል ርዕስ ያገኙታል።"},"en-US":{"lang":"Eng","greetings":"Hello","enter_fayda_no_text":"Enter Your Fayda Alias Number (FAN/FCN)","next":"Next","view_digital_id":"View Digital ID","card_information":"Card Information","logout":"Logout","verified":"Verified","not_verified":"Not Verified","view_back_side":"View Back Side","view_front_side":"View Front Side","we_could_not_find_your_id":"We couldn't find your ID. ","please_register":"Please Click on Register Button to Register","register":"Register Here!","download":"Download","view_full_size":"View Full Size","alert_logout":"Are you sure you want to logout?","yes":"yes","no":"no","sign_in_with_telebirr":"Sign In With Telebirr","not_registered":"Not registered for Fayda ID?","Verified":"Verified","Not_verified":"Not Verified","scan_qr_code_title":"Tap on Scan QR Code to Verify an ID","scan_qr_code":"Scan QR Code","done":"Done","Home":"Home","Verify":"Verify","rid_required":"Your Registration ID is required!","please_scan_the_qr_code":"Please scan the QR code ","enter_rid":"Or, Enter your Registration number below","resend_fin":"Resend FIN","lost_fin":"Lost Your FIN?","444_resend":"The RID is not Found!","444_resend_content":"Please contact our customer service (id.gov.et/help).","200_resend":"SMS is Successfully sent to your number","200_resend_content":"You can now use your FIN no to get your virtual id card.","503_resend":"Please try again after a week, Thank You!","503_resend_content":"Your FIN has been sent to your registered phone number via SMS. Please check your inbox.","error_resend":"Service not available, Please try again","error_resend_content":"It seems like there is a connection error","invalid_rid":"Invalid RID Number","invalid_rid_content":"Double-check your registration number. It's on the confirmation paper.","season_expired_title":"Session Expired!","season_expired_description":"To obtain your PDF copy, please log out and log in again.","logout_text":"Log Out","cancel_text":"Cancel","tooltip_info":"FIN is Fayda identification number And FAN is Fayda alias number,  Two of which can be found in your SMS text under the title National ID."}};
  for(var locale in newI18nRes){
    if(i18nRes[locale]){
      for(var key in newI18nRes[locale]){
        i18nRes[locale][key] = newI18nRes[locale][key];
      }
    }else{
      i18nRes[locale]=newI18nRes[locale];
    }
  }
})(__maI18nResource__)

/* maml-transpiler v0.0.28 2023-06-09 15:47:15 */
window.__maml_transpiler_version__='v0.0.28'
var $gmac,$gaic={}
$gma=function(path,global){
  if(typeof global==='undefined')global={};
  function _ac(parent,child){if(typeof(child)!='undefined')parent.children.push(child);} // appendChild
  function _cvn(key){ // createVirtualNode
    if(typeof(key)!='undefined')return {tag:'virtual','maKey':key,children:[]};
    return {tag:'virtual',children:[]};
  }
  function _ctn(tag){ // createTagNode
    $gmac++;
    if($gmac>=16000) throw 'Dom count exceeds maximum 16000.';
    return {tag:tag.substr(0,3)=='ma-'?tag:'ma-'+tag,attr:{},children:[],n:[]}
  }
  function _rtw(msg){console.warn("[MAML runtime warn][$gma] "+msg)} // runtimeWarn
  $gmal={warn:console.warn,info:console.log,error:console.error}
  function $gmah(){
    function fn(){}
    fn.prototype={
      hn:function(obj){ // object has new value
        if(typeof(obj)=='object'){
          var cnt=0,any=false;
          for(var x in obj){
            any|=x==='__value__';
            cnt++;
            if(cnt>2)break;
          }
          return cnt==2&&any&&obj.hasOwnProperty('__maspec__');
        }
        return false;
      },
      nh:function(obj,special){ // new has new value object
        return {__value__:obj,__maspec__:special?special:true}
      },
      rv:function(obj){ // readValue
        return this.hn(obj)?this.rv(obj.__value__):obj;
      }
    }
    return new fn;
  }
  mah=$gmah();
  function $gstack(s){
    var t=s.split('\n '+' '+' '+' ');
    for(var i=0;i<t.length;++i){
      if(0==i) continue;
      if(")"===t[i][t[i].length-1])
      t[i]=t[i].replace(/\s\(.*\)$/,"");
      else t[i]="at anonymous function";
    }
    return t.join('\n '+' '+' '+' ');
  }
  function $gdc(o,p,r){ // deep copy
    o=mah.rv(o);
    if(o===null||o===undefined) return o;
    if(o.constructor===String||o.constructor===Boolean||o.constructor===Number) return o;
    if(o.constructor===Object){
      var copy={};
      for(var key in o){
        if(o.hasOwnProperty(key))copy[undefined===p?key.substring(4):p+key]=$gdc(o[key],p,r);
      }
      return copy;
    }
    if(o.constructor===Date){
      var copy=new Date();
      copy.setTime(o.getTime());
      return copy;
    }
    if(o.constructor===Array){
      var copy=[];
      for(var index=0;index<o.length;index++)copy.push($gdc(o[index],p,r));
      return copy;
    }
    if(r&&o.constructor===Function){
      if (r==1)return $gdc(o(),undefined,2);
      if (r==2)return o;
    }
    if(o.constructor===RegExp){
      var m="";
      if(o.global)m+="g";
      if(o.ignoreCase)m+="i";
      if(o.multiline)m+="m";
      return new RegExp(o.source,m);
    }
    return null;
  }
  function $gmart(should_pass_type_info){
    function arithmeticEval(ops,e,s,g,o){
      var rop=ops[0][1],_f=false;
      var _a,_b,_c,_d,_aa,_bb;
      switch(rop){
        case '?:':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):rev(ops[3],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '&&':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?rev(ops[2],e,s,g,o,_f):mah.rv(_a);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '||':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=mah.rv(_a)?mah.rv(_a):rev(ops[2],e,s,g,o,_f);
          _d=_c&&!mah.hn(_d)?mah.nh(_d,'c'):_d;
          return _d;
        case '+':case '*':case '/':case '%':case '|':case '^':case '&':case '===':case '==':case '!=':case '!==':case '>=':case '<=':case '>':case '<':case '<<':case '>>':
          _a=rev(ops[1],e,s,g,o,_f);
          _b=rev(ops[2],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          switch(rop){
            case '+':
              _d=mah.rv(_a)+mah.rv(_b);
              break;
            case '*':
              _d=mah.rv(_a)*mah.rv(_b);
              break;
            case '/':
              _d=mah.rv(_a)/mah.rv(_b);
              break;
            case '%':
              _d=mah.rv(_a)%mah.rv(_b);
              break;
            case '|':
              _d=mah.rv(_a)|mah.rv(_b);
              break;
            case '^':
              _d=mah.rv(_a)^mah.rv(_b);
              break;
            case '&':
              _d=mah.rv(_a)&mah.rv(_b);
              break;
            case '===':
              _d=mah.rv(_a)===mah.rv(_b);
              break;
            case '==':
              _d=mah.rv(_a)==mah.rv(_b);
              break;
            case '!=':
              _d=mah.rv(_a)!=mah.rv(_b);
              break;
            case '!==':
              _d=mah.rv(_a)!==mah.rv(_b);
              break;
            case '>=':
              _d=mah.rv(_a)>=mah.rv(_b);
              break;
            case '<=':
              _d=mah.rv(_a)<=mah.rv(_b);
              break;
            case '>':
              _d=mah.rv(_a)>mah.rv(_b);
              break;
            case '<':
              _d=mah.rv(_a)<mah.rv(_b);
              break;
            case '<<':
              _d=mah.rv(_a)<<mah.rv(_b);
              break;
            case '>>':
              _d=mah.rv(_a)>>mah.rv(_b);
              break;
            default:
              break;
          }
          return _c?mah.nh(_d,"c"):_d;
        case '-':
          _a=ops.length===3?rev(ops[1],e,s,g,o,_f):0;
          _b=ops.length===3?rev(ops[2],e,s,g,o,_f):rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&(mah.hn(_a)||mah.hn(_b));
          _d=_c?mah.rv(_a)-mah.rv(_b):_a-_b;
          return _c?mah.nh(_d,"c"):_d;
        case '!':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=!mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        case '~':
          _a=rev(ops[1],e,s,g,o,_f);
          _c=should_pass_type_info&&mah.hn(_a);
          _d=~mah.rv(_a);
          return _c?mah.nh(_d,"c"):_d;
        default:
          $gmal.warn('unrecognized op'+rop);
      }
    }
    function rev(ops,e,s,g,o,newap){
      var op=ops[0],_f=false;
      if(typeof newap!=="undefined")o.ap=newap;
      if(typeof(op)==='object'){
        var vop=op[0];
        var _a,_aa,_b,_bb,_c,_d,_s,_e,_ta,_tb,_td;
        switch(vop){
          case 2: // LogicalExpression|ConditionalExpression|UnaryExpression|BinaryExpression
            return arithmeticEval(ops,e,s,g,o);
          case 4: // ArrayExpression
            return rev(ops[1],e,s,g,o,_f);
          case 5: // ArrayMember
            switch(ops.length){
              case 2: // one member
                return should_pass_type_info?[rev(ops[1],e,s,g,o,_f)]:[mah.rv(rev(ops[1],e,s,g,o,_f))];
              case 1: // empty
                return [];
              default: // more members
                _a=rev(ops[1],e,s,g,o,_f);
                _a.push(should_pass_type_info?rev(ops[2],e,s,g,o,_f):mah.rv(rev(ops[2],e,s,g,o,_f)));
                return _a;
            }
          case 6: // MemberExpression
            _a=rev(ops[1],e,s,g,o);
            var ap=o.ap;
            _ta=mah.hn(_a);
            _aa=_ta?mah.rv(_a):_a;
            o.is_affected|=_ta;
            if(should_pass_type_info){
              if(_aa===null||typeof(_aa)==='undefined'){
                return _ta?mah.nh(undefined,'e'):undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return (_ta||_tb)?mah.nh(undefined,'e'):undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return (_ta||_tb)?(_td?_d:mah.nh(_d,'e')):_d;
            }else{
              if(_aa===null||typeof(_aa)==='undefined'){
                return undefined;
              }
              _b=rev(ops[2],e,s,g,o,_f);
              _tb=mah.hn(_b);
              _bb=_tb?mah.rv(_b):_b;
              o.ap=ap;
              o.is_affected|=_tb;
              if(_bb===null||typeof(_bb)==='undefined'){
                return undefined;
              }
              _d=_aa[_bb];
              _td=mah.hn(_d);
              o.is_affected|=_td;
              return _td?mah.rv(_d):_d;
            }
          case 7: // Identifier
            switch(ops[1][0]){
              case 11: // CompoundExpression
                o.is_affected|=mah.hn(g);
                return g;
              case 3: // StaticString
                _s=mah.rv(s);
                _e=mah.rv(e);
                _b=ops[1][1];
                if(g&&g.f&&g.f.hasOwnProperty(_b)){
                  _a=g.f;
                  o.ap=true;
                }else{
                  _a=_s&&_s.hasOwnProperty(_b)?s:_e&&(_e.hasOwnProperty(_b)?e:undefined);
                }
                if(should_pass_type_info){
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    _d=_ta&&!_td?mah.nh(_d,'e'):_d;
                    return _d;
                  }
                }else{
                  if(_a){
                    _ta=mah.hn(_a);
                    _aa=_ta?mah.rv(_a):_a;
                    _d=_aa[_b];
                    _td=mah.hn(_d);
                    o.is_affected|=_ta||_td;
                    return mah.rv(_d);
                  }
                }
                return undefined;
            }
            break;
          case 8: // ObjectProperty
            _a={};
            _a[ops[1]]=rev(ops[2],e,s,g,o,_f);
            return _a;
          case 9: // ObjectExpression
            _a=rev(ops[1],e,s,g,o,_f);
            _b=rev(ops[2],e,s,g,o,_f);
            function merge(_a,_b,_ow){
              _ta=mah.hn(_a);
              _tb=mah.hn(_b);
              _aa=mah.rv(_a);
              _bb=mah.rv(_b);
              if(should_pass_type_info){
                if(_tb){
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=mah.nh(_bb[k],'e');
                  }
                }else{
                  for(var k in _bb){
                    if(_ow||!_aa.hasOwnProperty(k))_aa[k]=_bb[k];
                  }
                }
              }else{
                for(var k in _bb){
                  if(_ow||_aa.hasOwnProperty(k))_aa[k]=mah.rv(_bb[k]);
                }
              }
              return _a;
            }
            var _c=_a,_ow=true
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10){
              _a=_b,_b=_c,_ow=false
            }
            if(typeof(ops[1][0])==="object"&&ops[1][0][0]===10)return merge(merge({},_a,_ow),_b,_ow);
            else return merge(_a,_b,_ow);
          case 10: // SpreadProperty
            return should_pass_type_info?rev(ops[1],e,s,g,o,_f):mah.rv(rev(ops[1],e,s,g,o,_f));
          case 12: // CallExpression
            var _r;
            _a=rev(ops[1],e,s,g,o);
            if(!o.ap)return should_pass_type_info&&mah.hn(_a)?mah.nh(_r,'f'):_r;
            var ap=o.ap;
            _b=rev(ops[2],e,s,g,o,_f);
            o.ap=ap;
            _ta=mah.hn(_a);
            _tb=_ca(_b);
            _aa=mah.rv(_a);
            _bb=mah.rv(_b);
            snap_bb=$gdc(_bb,"sjs_");
            try{
              _r=typeof _aa==="function"?$gdc(_aa.apply(null,snap_bb)):undefined;
            }catch(e){
              e.message=e.message.replace(/sjs_/g,"");
              e.stack=e.stack.substring(0,e.stack.indexOf("\n",e.stack.lastIndexOf("at sjs_")));
              e.stack=e.stack.replace(/\ssjs_/g," ");
              e.stack=$gstack(e.stack);
              e.stack += "\n "+" "+" "+" at " + path;
              if(window.__layer__==='view')console.error(e);
              _r=undefined;
            }
            return should_pass_type_info&&(_tb||_ta)?mah.nh(_r,'f'):_r;
        }
      }else{
        if(op===3||op===1) // StaticConstant
          return ops[1];
        else if(op===11){ // CompoundExpression
          var _a='';
          for(var index=1;index<ops.length;index++){
            var xp=mah.rv(rev(ops[index],e,s,g,o,_f));
            _a+=typeof(xp)==='undefined'?'':xp;
          }
          return _a;
        }
      }
    }
    return rev;
  }
  gra=$gmart(true);
  grb=$gmart(false);
  function mfor(to_iter,func,env,_s,global,father,itemname,indexname,keyname){
    var _n=!mah.hn(to_iter);
    var scope=mah.rv(_s);
    var full=Object.prototype.toString.call(mah.rv(to_iter));
    var type=full[8];
    var old_index=scope[indexname];
    var old_item=scope[itemname];
    var has_old_index=scope.hasOwnProperty(indexname);
    var has_old_item=scope.hasOwnProperty(itemname);

    if(type==='N'&&full[10]==='l')type='X';
    var _y;
    if(_n){
      if(type==='A'){
        for(var index=0;index<to_iter.length;index++){
          scope[itemname]=to_iter[index];
          scope[indexname]=mah.nh(index,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[index])):_cvn(mah.rv(mah.rv(to_iter[index])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in to_iter){
          scope[itemname]=to_iter[k];
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(mah.rv(to_iter[k])):_cvn(mah.rv(mah.rv(to_iter[k])[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<to_iter.length;i++){
          scope[itemname]=to_iter[i];
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<to_iter;i++){
          scope[itemname]=i;
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }else{
      var r_to_iter=mah.rv(to_iter);
      var r_iter_item,iter_item;
      if(type==='A'){
        for(var i=0;i<r_to_iter.length;i++){
          iter_item=r_to_iter[i];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(i,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='O'){
        for(var k in r_to_iter){
          iter_item=r_to_iter[k];
          iter_item=!mah.hn(iter_item)?mah.nh(iter_item,'h'):iter_item;
          r_iter_item=mah.rv(iter_item);
          scope[itemname]=iter_item;
          scope[indexname]=mah.nh(k,'h');
          _y=keyname?(keyname==="*this"?_cvn(r_iter_item):_cvn(mah.rv(r_iter_item[keyname]))):_cvn();
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='S'){
        for(var i=0;i<r_to_iter.length;i++){
          scope[itemname]=mah.nh(r_to_iter[i],'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(to_iter[i]+i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }else if(type==='N'){
        for(var i=0;i<r_to_iter;i++){
          scope[itemname]=mah.nh(i,'h');
          scope[indexname]=mah.nh(i,'h');
          _y=_cvn(i);
          _ac(father,_y);
          func(env,scope,_y,global);
        }
      }
    }
    if(has_old_index){
      scope[indexname]=old_index;
    }else{
      delete scope[indexname];
    }
    if(has_old_item){
      scope[itemname]=old_item;
    }else{
      delete scope[itemname];
    }
  }
  function _ca(obj){
    if(mah.hn(obj))return true;
    if(typeof obj!=="object")return false;
    for(var i in obj){
      if(obj.hasOwnProperty(i)){
        if(_ca(obj[i]))return true;
      }
    }
    return false;
  }
  function _setAttr(z,node,attrname,opindex,env,scope,global){
    var o={},raw=grb(z[opindex],env,scope,global,o),value=$gdc(raw,"",2);
    if(o.is_affected||_ca(raw))node.n.push(attrname); // new attr
    node.attr[attrname]=value;
  }
  function _o(z,opindex,env,scope,global){
    var nothing={};
    return grb(z[opindex],env,scope,global,nothing);
  }
  function _1(z,opindex,env,scope,global){
    var nothing={};
    return gra(z[opindex],env,scope,global,nothing);
  }
  function _2(z,opindex,func,env,scope,global,father,itemname,indexname,keyname){
    var to_iter=_1(z,opindex,env,scope,global,father,itemname,indexname,keyname);
    mfor(to_iter,func,env,scope,global,father,itemname,indexname,keyname);
  }
  function _setAttrs(z,tag,attrs,env,scope,global){
    var t=_ctn(tag),base=0;
    for(var i=0;i<attrs.length;i+=2){
      if(attrs[i+1]<0){
        t.attr[attrs[i]]=true;
      }else{
        _setAttr(z,t,attrs[i],base+attrs[i+1],env,scope,global);
        if(base===0)base=attrs[i+1];
      }
    }
    return t;
  }

  var sjs_init=function(){
    if(!__MAML_GLOBAL__.sjs_init){
      sjs_Object();sjs_Function();sjs_Array();sjs_String();sjs_Boolean();sjs_Number();sjs_Math();sjs_Date();sjs_RegExp();
    }
    __MAML_GLOBAL__.sjs_init=true;
  };
  var sjs_Object=function(){
    Object.defineProperty(Object.prototype,"sjs_constructor",{writable:true,value:"Object"})
    Object.defineProperty(Object.prototype,"sjs_toString",{writable:true,value:function(){return "[object Object]"}})
  }
  var sjs_Function=function(){
    Object.defineProperty(Function.prototype,"sjs_constructor",{writable:true,value:"Function"})
    Object.defineProperty(Function.prototype,"sjs_toString",{writable:true,value:function(){return "[function Function]"}})
    Object.defineProperty(Function.prototype,"sjs_length",{get:function(){return this.length;},set:function(){}});
  }
  var sjs_Array=function(){
    Object.defineProperty(Array.prototype,"sjs_constructor",{writable:true,value:"Array"})
    Object.defineProperty(Array.prototype,"sjs_toString",{writable:true,value:function(){return this.nv_join();}})
    Object.defineProperty(Array.prototype,"sjs_join",{writable:true,value:function(s){
      s=undefined==s?',':s;var r="";
      for(var i=0;i<this.length;++i){
        if(0!=i)r+=s;
        if(null==this[i]||undefined==this[i])r+='';
        else if(this[i].nv_constructor==="Array"&&typeof this[i]=='object')r+=this[i].nv_join();
        else if(typeof this[i]=='function')r+=this[i].nv_toString();
        else r+=this[i].toString();
      }
      return r;
    }})
    Object.defineProperty(Array.prototype,"sjs_concat",{writable:true,value:Array.prototype.concat})
    Object.defineProperty(Array.prototype,"sjs_pop",{writable:true,value:Array.prototype.pop})
    Object.defineProperty(Array.prototype,"sjs_push",{writable:true,value:Array.prototype.push})
    Object.defineProperty(Array.prototype,"sjs_reverse",{writable:true,value:Array.prototype.reverse})
    Object.defineProperty(Array.prototype,"sjs_shift",{writable:true,value:Array.prototype.shift})
    Object.defineProperty(Array.prototype,"sjs_slice",{writable:true,value:Array.prototype.slice})
    Object.defineProperty(Array.prototype,"sjs_sort",{writable:true,value:Array.prototype.sort})
    Object.defineProperty(Array.prototype,"sjs_splice",{writable:true,value:Array.prototype.splice})
    Object.defineProperty(Array.prototype,"sjs_unshift",{writable:true,value:Array.prototype.unshift})
    Object.defineProperty(Array.prototype,"sjs_indexOf",{writable:true,value:Array.prototype.indexOf})
    Object.defineProperty(Array.prototype,"sjs_lastIndexOf",{writable:true,value:Array.prototype.lastIndexOf})
    Object.defineProperty(Array.prototype,"sjs_every",{writable:true,value:Array.prototype.every})
    Object.defineProperty(Array.prototype,"sjs_some",{writable:true,value:Array.prototype.some})
    Object.defineProperty(Array.prototype,"sjs_forEach",{writable:true,value:Array.prototype.forEach})
    Object.defineProperty(Array.prototype,"sjs_map",{writable:true,value:Array.prototype.map})
    Object.defineProperty(Array.prototype,"sjs_filter",{writable:true,value:Array.prototype.filter})
    Object.defineProperty(Array.prototype,"sjs_reduce",{writable:true,value:Array.prototype.reduce})
    Object.defineProperty(Array.prototype,"sjs_reduceRight",{writable:true,value:Array.prototype.reduceRight})
    Object.defineProperty(Array.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_String=function(){
    Object.defineProperty(String.prototype,"sjs_constructor",{writable:true,value:"String"})
    Object.defineProperty(String.prototype,"sjs_toString",{writable:true,value:String.prototype.toString})
    Object.defineProperty(String.prototype,"sjs_valueOf",{writable:true,value:String.prototype.valueOf})
    Object.defineProperty(String.prototype,"sjs_charAt",{writable:true,value:String.prototype.charAt})
    Object.defineProperty(String.prototype,"sjs_charCodeAt",{writable:true,value:String.prototype.charCodeAt})
    Object.defineProperty(String.prototype,"sjs_concat",{writable:true,value:String.prototype.concat})
    Object.defineProperty(String.prototype,"sjs_indexOf",{writable:true,value:String.prototype.indexOf})
    Object.defineProperty(String.prototype,"sjs_lastIndexOf",{writable:true,value:String.prototype.lastIndexOf})
    Object.defineProperty(String.prototype,"sjs_localeCompare",{writable:true,value:String.prototype.localeCompare})
    Object.defineProperty(String.prototype,"sjs_match",{writable:true,value:String.prototype.match})
    Object.defineProperty(String.prototype,"sjs_replace",{writable:true,value:String.prototype.replace})
    Object.defineProperty(String.prototype,"sjs_search",{writable:true,value:String.prototype.search})
    Object.defineProperty(String.prototype,"sjs_slice",{writable:true,value:String.prototype.slice})
    Object.defineProperty(String.prototype,"sjs_split",{writable:true,value:String.prototype.split})
    Object.defineProperty(String.prototype,"sjs_substring",{writable:true,value:String.prototype.substring})
    Object.defineProperty(String.prototype,"sjs_toLowerCase",{writable:true,value:String.prototype.toLowerCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleLowerCase",{writable:true,value:String.prototype.toLocaleLowerCase})
    Object.defineProperty(String.prototype,"sjs_toUpperCase",{writable:true,value:String.prototype.toUpperCase})
    Object.defineProperty(String.prototype,"sjs_toLocaleUpperCase",{writable:true,value:String.prototype.toLocaleUpperCase})
    Object.defineProperty(String.prototype,"sjs_trim",{writable:true,value:String.prototype.trim})
    Object.defineProperty(String.prototype,"sjs_length",{get:function(){return this.length;},set:function(value){this.length=value;}});
  }
  var sjs_Boolean=function(){
    Object.defineProperty(Boolean.prototype,"sjs_constructor",{writable:true,value:"Boolean"})
    Object.defineProperty(Boolean.prototype,"sjs_toString",{writable:true,value:Boolean.prototype.toString})
    Object.defineProperty(Boolean.prototype,"sjs_valueOf",{writable:true,value:Boolean.prototype.valueOf})
  }
  var sjs_Number=function(){
    Object.defineProperty(Number,"sjs_MAX_VALUE",{writable:false,value:Number.MAX_VALUE})
    Object.defineProperty(Number,"sjs_MIN_VALUE",{writable:false,value:Number.MIN_VALUE})
    Object.defineProperty(Number,"sjs_NEGATIVE_INFINITY",{writable:false,value:Number.NEGATIVE_INFINITY})
    Object.defineProperty(Number,"sjs_POSITIVE_INFINITY",{writable:false,value:Number.POSITIVE_INFINITY})
    Object.defineProperty(Number.prototype,"sjs_constructor",{writable:true,value:"Number"})
    Object.defineProperty(Number.prototype,"sjs_toString",{writable:true,value:Number.prototype.toString})
    Object.defineProperty(Number.prototype,"sjs_toLocaleString",{writable:true,value:Number.prototype.toLocaleString})
    Object.defineProperty(Number.prototype,"sjs_valueOf",{writable:true,value:Number.prototype.valueOf})
    Object.defineProperty(Number.prototype,"sjs_toFixed",{writable:true,value:Number.prototype.toFixed})
    Object.defineProperty(Number.prototype,"sjs_toExponential",{writable:true,value:Number.prototype.toExponential})
    Object.defineProperty(Number.prototype,"sjs_toPrecision",{writable:true,value:Number.prototype.toPrecision})
  }
  var sjs_Math=function(){
    Object.defineProperty(Math,"sjs_E",{writable:false,value:Math.E})
    Object.defineProperty(Math,"sjs_LN10",{writable:false,value:Math.LN10})
    Object.defineProperty(Math,"sjs_LN2",{writable:false,value:Math.LN2})
    Object.defineProperty(Math,"sjs_LOG2E",{writable:false,value:Math.LOG2E})
    Object.defineProperty(Math,"sjs_LOG10E",{writable:false,value:Math.LOG10E})
    Object.defineProperty(Math,"sjs_PI",{writable:false,value:Math.PI})
    Object.defineProperty(Math,"sjs_SQRT1_2",{writable:false,value:Math.SQRT1_2})
    Object.defineProperty(Math,"sjs_SQRT2",{writable:false,value:Math.SQRT2})
    Object.defineProperty(Math,"sjs_abs",{writable:false,value:Math.abs})
    Object.defineProperty(Math,"sjs_acos",{writable:false,value:Math.acos})
    Object.defineProperty(Math,"sjs_asin",{writable:false,value:Math.asin})
    Object.defineProperty(Math,"sjs_atan",{writable:false,value:Math.atan})
    Object.defineProperty(Math,"sjs_atan2",{writable:false,value:Math.atan2})
    Object.defineProperty(Math,"sjs_ceil",{writable:false,value:Math.ceil})
    Object.defineProperty(Math,"sjs_cos",{writable:false,value:Math.cos})
    Object.defineProperty(Math,"sjs_exp",{writable:false,value:Math.exp})
    Object.defineProperty(Math,"sjs_floor",{writable:false,value:Math.floor})
    Object.defineProperty(Math,"sjs_log",{writable:false,value:Math.log})
    Object.defineProperty(Math,"sjs_max",{writable:false,value:Math.max})
    Object.defineProperty(Math,"sjs_min",{writable:false,value:Math.min})
    Object.defineProperty(Math,"sjs_pow",{writable:false,value:Math.pow})
    Object.defineProperty(Math,"sjs_random",{writable:false,value:Math.random})
    Object.defineProperty(Math,"sjs_round",{writable:false,value:Math.round})
    Object.defineProperty(Math,"sjs_sin",{writable:false,value:Math.sin})
    Object.defineProperty(Math,"sjs_sqrt",{writable:false,value:Math.sqrt})
    Object.defineProperty(Math,"sjs_tan",{writable:false,value:Math.tan})
  }
  var sjs_Date=function(){
    Object.defineProperty(Date.prototype,"sjs_constructor",{writable:true,value:"Date"})
    Object.defineProperty(Date,"sjs_parse",{writable:true,value:Date.parse})
    Object.defineProperty(Date,"sjs_UTC",{writable:true,value:Date.UTC})
    Object.defineProperty(Date,"sjs_now",{writable:true,value:Date.now})
    Object.defineProperty(Date.prototype,"sjs_toString",{writable:true,value:Date.prototype.toString})
    Object.defineProperty(Date.prototype,"sjs_toDateString",{writable:true,value:Date.prototype.toDateString})
    Object.defineProperty(Date.prototype,"sjs_toTimeString",{writable:true,value:Date.prototype.toTimeString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleString",{writable:true,value:Date.prototype.toLocaleString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleDateString",{writable:true,value:Date.prototype.toLocaleDateString})
    Object.defineProperty(Date.prototype,"sjs_toLocaleTimeString",{writable:true,value:Date.prototype.toLocaleTimeString})
    Object.defineProperty(Date.prototype,"sjs_valueOf",{writable:true,value:Date.prototype.valueOf})
    Object.defineProperty(Date.prototype,"sjs_getTime",{writable:true,value:Date.prototype.getTime})
    Object.defineProperty(Date.prototype,"sjs_getFullYear",{writable:true,value:Date.prototype.getFullYear})
    Object.defineProperty(Date.prototype,"sjs_getUTCFullYear",{writable:true,value:Date.prototype.getUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_getMonth",{writable:true,value:Date.prototype.getMonth})
    Object.defineProperty(Date.prototype,"sjs_getUTCMonth",{writable:true,value:Date.prototype.getUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_getDate",{writable:true,value:Date.prototype.getDate})
    Object.defineProperty(Date.prototype,"sjs_getUTCDate",{writable:true,value:Date.prototype.getUTCDate})
    Object.defineProperty(Date.prototype,"sjs_getDay",{writable:true,value:Date.prototype.getDay})
    Object.defineProperty(Date.prototype,"sjs_getUTCDay",{writable:true,value:Date.prototype.getUTCDay})
    Object.defineProperty(Date.prototype,"sjs_getHours",{writable:true,value:Date.prototype.getHours})
    Object.defineProperty(Date.prototype,"sjs_getUTCHours",{writable:true,value:Date.prototype.getUTCHours})
    Object.defineProperty(Date.prototype,"sjs_getMinutes",{writable:true,value:Date.prototype.getMinutes})
    Object.defineProperty(Date.prototype,"sjs_getUTCMinutes",{writable:true,value:Date.prototype.getUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_getSeconds",{writable:true,value:Date.prototype.getSeconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCSeconds",{writable:true,value:Date.prototype.getUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_getMilliseconds",{writable:true,value:Date.prototype.getMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getUTCMilliseconds",{writable:true,value:Date.prototype.getUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_getTimezoneOffset",{writable:true,value:Date.prototype.getTimezoneOffset})
    Object.defineProperty(Date.prototype,"sjs_setTime",{writable:true,value:Date.prototype.setTime})
    Object.defineProperty(Date.prototype,"sjs_setMilliseconds",{writable:true,value:Date.prototype.setMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCMilliseconds",{writable:true,value:Date.prototype.setUTCMilliseconds})
    Object.defineProperty(Date.prototype,"sjs_setSeconds",{writable:true,value:Date.prototype.setSeconds})
    Object.defineProperty(Date.prototype,"sjs_setUTCSeconds",{writable:true,value:Date.prototype.setUTCSeconds})
    Object.defineProperty(Date.prototype,"sjs_setMinutes",{writable:true,value:Date.prototype.setMinutes})
    Object.defineProperty(Date.prototype,"sjs_setUTCMinutes",{writable:true,value:Date.prototype.setUTCMinutes})
    Object.defineProperty(Date.prototype,"sjs_setHours",{writable:true,value:Date.prototype.setHours})
    Object.defineProperty(Date.prototype,"sjs_setUTCHours",{writable:true,value:Date.prototype.setUTCHours})
    Object.defineProperty(Date.prototype,"sjs_setDate",{writable:true,value:Date.prototype.setDate})
    Object.defineProperty(Date.prototype,"sjs_setUTCDate",{writable:true,value:Date.prototype.setUTCDate})
    Object.defineProperty(Date.prototype,"sjs_setMonth",{writable:true,value:Date.prototype.setMonth})
    Object.defineProperty(Date.prototype,"sjs_setUTCMonth",{writable:true,value:Date.prototype.setUTCMonth})
    Object.defineProperty(Date.prototype,"sjs_setFullYear",{writable:true,value:Date.prototype.setFullYear})
    Object.defineProperty(Date.prototype,"sjs_setUTCFullYear",{writable:true,value:Date.prototype.setUTCFullYear})
    Object.defineProperty(Date.prototype,"sjs_toUTCString",{writable:true,value:Date.prototype.toUTCString})
    Object.defineProperty(Date.prototype,"sjs_toISOString",{writable:true,value:Date.prototype.toISOString})
    Object.defineProperty(Date.prototype,"sjs_toJSON",{writable:true,value:Date.prototype.toJSON})
  }
  var sjs_RegExp=function(){
    Object.defineProperty(RegExp.prototype,"sjs_constructor",{writable:true,value:"RegExp"})
    Object.defineProperty(RegExp.prototype,"sjs_exec",{writable:true,value:RegExp.prototype.exec})
    Object.defineProperty(RegExp.prototype,"sjs_test",{writable:true,value:RegExp.prototype.test})
    Object.defineProperty(RegExp.prototype,"sjs_toString",{writable:true,value:RegExp.prototype.toString})
    Object.defineProperty(RegExp.prototype,"sjs_source",{get:function(){return this.source;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_global",{get:function(){return this.global;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_ignoreCase",{get:function(){return this.ignoreCase;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_multiline",{get:function(){return this.multiline;},set:function(){}});
    Object.defineProperty(RegExp.prototype,"sjs_lastIndex",{get:function(){return this.lastIndex;},set:function(v){this.lastIndex=v;}});
  }
  sjs_init();
  // sjs global object or function
  var sjs_getDate=function(){var args=Array.prototype.slice.call(arguments);args.unshift(Date);return new(Function.prototype.bind.apply(Date,args));}
  var sjs_getRegExp=function(){var args=Array.prototype.slice.call(arguments);args.unshift(RegExp);return new(Function.prototype.bind.apply(RegExp,args));}
  var sjs_console={sjs_log:function(){if(window.__layer__==='view'){var res="[SJS runtime info] ";for(var i=0;i<arguments.length;++i)res+=arguments[i]+" ";console.log(res);}}}
  var sjs_parseInt=parseInt,sjs_parseFloat=parseFloat,sjs_isNaN=isNaN,sjs_isFinite=isFinite,sjs_decodeURI=decodeURI,sjs_decodeURIComponent=decodeURIComponent,sjs_encodeURI=encodeURI,sjs_encodeURIComponent=encodeURIComponent;
  var sjs_JSON={
    sjs_stringify:function(o){return JSON.stringify($gdc(o));},
    sjs_parse:function(s){
      if(s===undefined)return undefined;
      return $gdc(JSON.parse(s),'sjs_');
    }
  }
  function _ck(k){return null==k?undefined:'number'===typeof k?k:"sjs_"+k} // compute key for sjs a[key]

  function _grp(path,e,me){if(path[0]!='/'){var mepart=me.split('/');mepart.pop();var ppart=path.split('/');for(var index=0;index<ppart.length;index++){if(ppart[index]=='..')mepart.pop();else if(ppart[index]=='.'||!ppart[index])continue;else mepart.push(ppart[index]);}path=mepart.join('/');}if(me[0]=='.'&&path[0]=='/')path='.'+path;if(e[path])return path;if(e[path+'.maml'])return path+'.maml';} // getRelativePath

  function _ai(i,path,e,me,r,c){var rp=_grp(path,e,me);if(rp)i.push(rp);else{i.push('');_rtw(me+':import:'+r+':'+c+': Path `'+path+'` not found from `'+me+'`.')}} // import

  function _gapi(e, path) {
    if (!path) return [];
    if ($gaic[path]) {
      return $gaic[path];
    }
    var ret = [],
      qq = [],
      hh = 0,
      tt = 0,
      put = {},
      visited = {};
    qq.push(path);
    visited[path] = true;
    tt++;
    while (hh < tt) {
      var a = qq[hh++];
      for (var index = 0; index < e[a].ic.length; index++) {
        var nd = e[a].ic[index];
        var np = _grp(nd, e, a);
        if (np && !visited[np]) {
          visited[np] = true;
          qq.push(np);
          tt++;
        }
      }
      for (var index = 0; a != path && index < e[a].ti.length; index++) {
        var ni = e[a].ti[index];
        var nm = _grp(ni, e, a);
        if (nm && !put[nm]) {
        }
      }
    }
    $gaic[path] = ret;
    return ret;
  }

  function _gd(p, c, e, d) {
    if (!c) return;
    if (d[p][c]) return d[p][c];
    for (var index = e[p].i.length - 1; index >= 0; index--) {
      if (e[p].i[index] && d[e[p].i[index]][c]) return d[e[p].i[index]][c];
    }
    for (var index = e[p].ti.length - 1; index >= 0; index--) {
      var q = _grp(e[p].ti[index], e, p);
      if (q && d[q][c]) return d[q][c];
    }
    var api = _gapi(e, p);
    for (var index = 0; index < api.length; index++) {
      if (api[index] && d[api[index]][c]) return d[api[index]][c];
    }
    for (var key = e[p].j.length - 1; key >= 0; key--)
      if (e[p].j[key]) {
        for (var qlen = e[e[p].j[key]].ti.length - 1; qlen >= 0; qlen--) {
          var tt = _grp(e[e[p].j[key]].ti[qlen], e, p);
          if (tt && d[tt][c]) {
            return d[tt][c];
          }
        }
      }
  }
  
  var $ixc = {};
  function _ic(p,ent,me,e,s,r,gg){var x=_grp(p,ent,me);ent[me].j.push(x);if(x){if($ixc[x]){_rtw('-1:include:-1:-1: `'+p+'` is being included in a loop, will be stop.');return;}$ixc[x]=true;try{ent[x].f(e,s,r,gg)}catch(e){}$ixc[x]=false;}else{_rtw(me+':include:-1:-1: Included path `'+p+'` not found from `'+me+'`.')}} // include
  function _w(tn,f,line,c){_rtw(f+':template:'+line+':'+c+': Template `'+tn+'` not found.');}

  var e_=__MAML_GLOBAL__.entrys||{},d_=__MAML_GLOBAL__.defines||{},f_=__MAML_GLOBAL__.modules||{},p_={};
  if(window.i18n&&!f_.i18n){ // init sjs i18n api, remove arguments property sjs prefix
    f_.i18n={}
    for(var k in i18n){
      (function(k){ // simulate for loop let
        var key=k
        i18n['sjs_'+k]=i18n[k]
        if(typeof i18n[k]==="function"){
          i18n['sjs_'+k]=function(){return i18n[key].apply(null,$gdc(Array.prototype.slice.call(arguments)))}
          f_.i18n[k]=i18n['sjs_'+k]
        }else{
          i18n['sjs_'+k]=i18n[k]
          f_.i18n[k]=i18n[k]
        }
      })(k)
    }
  }
  __MAML_GLOBAL__.ops_cached=__MAML_GLOBAL__.ops_cached||{};
  __MAML_GLOBAL__.ops_set=__MAML_GLOBAL__.ops_set||{};
  __MAML_GLOBAL__.ops_init=__MAML_GLOBAL__.ops_init||{};
  var z=__MAML_GLOBAL__.ops_set.$gma||[];
  
  function gz$gma_1(){
    if(__MAML_GLOBAL__.ops_cached.$gma_1)return __MAML_GLOBAL__.ops_cached.$gma_1
    __MAML_GLOBAL__.ops_cached.$gma_1=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'mai']);
      Z([[7],[3,"autoplay"]]);
      Z([3,'clickButton']);
      Z([[7],[3,"circular"]]);
      Z([3,'swiper']);
      Z([[7],[3,"duration"]]);
      Z([[7],[3,"easingFunction"]]);
      Z([[7],[3,"indicatorActiveColor"]]);
      Z([[7],[3,"indicatorColor"]]);
      Z([[7],[3,"interval"]]);
      Z([[7],[3,"vertical"]]);
      Z([[7],[3,"background"]]);
      Z([3,'*this']);
      Z([3,' id']);
      Z([3,'idcard']);
      Z([3,'widthFix']);
      Z([[7],[3,"fronts"]]);
      Z([3,'id']);
      Z([[7],[3,"backs"]]);
      Z([3,'captionHolder']);
      Z([3,'caption']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"view_full_size"]]]]);
      Z([3,'information']);
      Z([3,'holder']);
      Z([3,'title']);
      Z([3,'ሙሉ ስም']);
      Z([3,'info']);
      Z([11,[[7],[3,"fullName_amh"]]]);
      Z([3,'breakLine']);
      Z([3,'Full Name']);
      Z([11,[[7],[3,"fullName_eng"]]]);
      Z([3,'የትውልድ ቀን']);
      Z([11,[[7],[3,"dob_et"]]]);
      Z([3,'Date of Birth']);
      Z([11,[[7],[3,"dob_eng"]]]);
      Z([3,'ጾታ | Sex']);
      Z([11,[[7],[3,"sex_amh"]],[3,' | '],[[7],[3,"sex_eng"]]]);
      Z([3,'ስልክ ቁጥር | Phone Number']);
      Z([11,[[7],[3,"phone"]]]);
      Z([3,'ክልል | Region']);
      Z([11,[[7],[3,"region_amh"]],[3,' | '],[[7],[3,"region_eng"]]]);
      Z([3,'ክ/ከተማ / ዞን | Subcity / Zone']);
      Z([11,[[7],[3,"zone_amh"]],[3,' | '],[[7],[3,"zone_eng"]]]);
      Z([3,'ወረዳ | Woreda']);
      Z([11,[[7],[3,"woreda_amh"]],[3,' | '],[[7],[3,"woreda_eng"]]]);
      Z([3,'ዜግነት | Citizenship']);
      Z([3,'small-text']);
      Z([3,'በተገለጸው መሰረት | Self Declared']);
      Z([11,[[7],[3,"citizenship_amh"]],[3,' | '],[[7],[3,"citizenship_Eng"]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_1);
    return __MAML_GLOBAL__.ops_cached.$gma_1
  }
  function gz$gma_2(){
    if(__MAML_GLOBAL__.ops_cached.$gma_2)return __MAML_GLOBAL__.ops_cached.$gma_2
    __MAML_GLOBAL__.ops_cached.$gma_2=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'con']);
      Z([3,'imageholder']);
      Z([3,'id-front-img']);
      Z([3,'widthFix']);
      Z([[7],[3,"backs"]]);
      Z([3,'bottomContainer']);
      Z([3,'toggleId']);
      Z([3,'toggle-btn']);
      Z([[7],[3,"loading_next"]]);
      Z([3,'']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"view_front_side"]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"download"]]]]);
      Z([3,'downloadImg']);
      Z([3,'downloadIcon']);
      Z([3,'black']);
      Z([3,'normal']);
      Z([3,'download'])
    })(__MAML_GLOBAL__.ops_cached.$gma_2);
    return __MAML_GLOBAL__.ops_cached.$gma_2
  }
  function gz$gma_3(){
    if(__MAML_GLOBAL__.ops_cached.$gma_3)return __MAML_GLOBAL__.ops_cached.$gma_3
    __MAML_GLOBAL__.ops_cached.$gma_3=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'con']);
      Z([3,'imageholder']);
      Z([3,'id-front-img']);
      Z([3,'widthFix']);
      Z([[7],[3,"fronts"]]);
      Z([3,'bottomContainer']);
      Z([3,'toggleId']);
      Z([3,'toggle-btn']);
      Z([3,'']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"view_back_side"]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"download"]]]]);
      Z([3,'downloadImg']);
      Z([3,'downloadIcon']);
      Z([3,'black']);
      Z([3,'normal']);
      Z([3,'download'])
    })(__MAML_GLOBAL__.ops_cached.$gma_3);
    return __MAML_GLOBAL__.ops_cached.$gma_3
  }
  function gz$gma_4(){
    if(__MAML_GLOBAL__.ops_cached.$gma_4)return __MAML_GLOBAL__.ops_cached.$gma_4
    __MAML_GLOBAL__.ops_cached.$gma_4=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'main']);
      Z([3,'background-color:re; padding-top:60px']);
      Z([[2,"==="], [[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"lang"]]], [1,"አማ"]]);
      Z([3,'toggleLocale']);
      Z([3,'position: absolute; top: 0; right: 20px;']);
      Z([3,'Eng']);
      Z([3,'widthFix']);
      Z([[7],[3,"src"]]);
      Z([3,'width: 300px; margin-top: -200px;']);
      Z([[2,"!"],[[6],[[7],[3,"userData"]],[3,"nickName"]]]);
      Z([3,'applyH5Token']);
      Z([3,'true']);
      Z([[7],[3,"loading"]]);
      Z([3,'margin-top: 30px; background-color:#09384f;box-shadow: 0 0 10px rgba(4, 38, 78, 0.7);']);
      Z([3,'primary']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"sign_in_with_telebirr"]]]]);
      Z([3,'clickButton']);
      Z([3,'form']);
      Z([3,'faydaLogin']);
      Z([3,'background-color:yello']);
      Z([3,'holderF']);
      Z([3,'background-color:gree']);
      Z([3,'color: #09384f; font-weight:700']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"greetings"]]],[3,' '],[[6],[[7],[3,"userData"]],[3,"nickName"]]]);
      Z([3,'holdFButtonAndText']);
      Z([3,'title']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"enter_fayda_no_text"]]]]);
      Z([3,'bindInfoDisplay']);
      Z([3,'iconContainer']);
      Z([3,'22']);
      Z([3,'info']);
      Z([3,'tooltip-container']);
      Z([[2,'?:'],[[7],[3,"displayInfo"]],[1,"tooltip"],[1,"tooltip-hidden"]]);
      Z([3,'tooltip']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"tooltip_info"]]]]);
      Z([3,'holder']);
      Z([3,'background-color:blu']);
      Z([3,'bindInput']);
      Z([3,'uin-input']);
      Z([3,'19']);
      Z([3,'uin']);
      Z([3,'0000-0000-0000-0000']);
      Z([3,'idcard']);
      Z([3,'footer']);
      Z([3,'next']);
      Z([3,'next-button']);
      Z([3,'submit']);
      Z([[7],[3,"loading_next"]]);
      Z([3,'login-text']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"next"]]]]);
      Z([3,'lostUinContainer']);
      Z([3,'lostUIN']);
      Z([3,'lostuin-button']);
      Z([3,'lostfin-text']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"lost_fin"]]]]);
      Z([3,'error']);
      Z([[7],[3,"failed"]]);
      Z([3,'alert']);
      Z([3,'t']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"we_could_not_find_your_id"]]]]);
      Z([3,'ta']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"please_register"]]]]);
      Z([[2,"!"],[[7],[3,"failed"]]]);
      Z([3,'not_registered']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"not_registered"]]]]);
      Z([3,'openLink']);
      Z([3,'register_btn_signinpage']);
      Z([3,'login_text_signinpage']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"register"]]]]);
      Z([3,'register-btn']);
      Z([3,'register-text']);
      Z([[2,"==="], [[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"lang"]]], [1,"Eng"]]);
      Z([3,'አማ']);
      Z([3,'title_EnterFin_Eng']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"we_could_not_find_your_id"]]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_4);
    return __MAML_GLOBAL__.ops_cached.$gma_4
  }
  function gz$gma_5(){
    if(__MAML_GLOBAL__.ops_cached.$gma_5)return __MAML_GLOBAL__.ops_cached.$gma_5
    __MAML_GLOBAL__.ops_cached.$gma_5=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'con']);
      Z([3,'']);
      Z([[2,"==="], [[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"lang"]]], [1,"አማ"]]);
      Z([3,'resend_sms']);
      Z([3,'form']);
      Z([3,'smsResend']);
      Z([3,'holderF']);
      Z([3,'title']);
      Z([3,'color:; opacity:0.5']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"rid_required"]]]]);
      Z([3,'margin-top:20px']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"please_scan_the_qr_code"]]]]);
      Z([3,'imagebox']);
      Z([3,'background-color:gree; ']);
      Z([3,'imagee']);
      Z([3,'widthFix']);
      Z([[7],[3,"src"]]);
      Z([3,'next']);
      Z([3,'scanCode']);
      Z([3,'next-btn']);
      Z([3,'login-text']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"scan_qr_code"]]]]);
      Z([3,'background-color:yello; width:100%']);
      Z([3,'or']);
      Z([3,'font-weight:500']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"enter_rid"]]]]);
      Z([[7],[3,"success200"]]);
      Z([3,'success']);
      Z([3,'success-message']);
      Z([3,'error_title']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"200_resend"]]]]);
      Z([3,'error_content']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"200_resend_content"]]]]);
      Z([[7],[3,"failed_input"]]);
      Z([3,'error']);
      Z([3,'error-message']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"invalid_rid"]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"invalid_rid_content"]]]]);
      Z([[7],[3,"failed444"]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"444_resend"]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"444_resend_content"]]]]);
      Z([[7],[3,"failed503"]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"503_resend"]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"503_resend_content"]]]]);
      Z([[7],[3,"failed_all"]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"error_resend"]]]]);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"error_resend_content"]]]]);
      Z([3,'holder']);
      Z([3,'bindInput']);
      Z([3,'uin-input']);
      Z([3,'35']);
      Z([3,'rid']);
      Z([3,'0000-0000-0000-0000-0000-0000-00000']);
      Z([3,'idcard']);
      Z([[7],[3,"rid_input"]]);
      Z([3,'footer']);
      Z([3,'background-color:viole']);
      Z([3,'true']);
      Z([3,'submit']);
      Z([[7],[3,"loading_next"]]);
      Z([3,'margin-top: 10px; background-color:#09384f;box-shadow: 0 0 10px rgba(4, 38, 78, 0.7);']);
      Z([3,'primary']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"resend_fin"]]]]);
      Z([3,'english-success-message'])
    })(__MAML_GLOBAL__.ops_cached.$gma_5);
    return __MAML_GLOBAL__.ops_cached.$gma_5
  }
  function gz$gma_6(){
    if(__MAML_GLOBAL__.ops_cached.$gma_6)return __MAML_GLOBAL__.ops_cached.$gma_6
    __MAML_GLOBAL__.ops_cached.$gma_6=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'box']);
      Z([3,'top-content']);
      Z([3,'imageBox']);
      Z([3,'profile-pic']);
      Z([3,'aspectFill']);
      Z([[7],[3,"image"]]);
      Z([3,'full-name']);
      Z([11,[[2,'?:'],[[2,"==="], [[12],[[6],[[7],[3,"i18n"]],[3,"getLocale"]],[[5]]], [1,"am-ET"]],[[7],[3,"fullName_amh"]],[[7],[3,"fullName"]]]]);
      Z([3,'details']);
      Z([[2,'?:'],[[7],[3,"verified"]],[1,"success"],[1,"cancel"]]);
      Z([3,'verified-txt']);
      Z([11,[[2,'?:'],[[7],[3,"verified"]],[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"verified"]]],[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"not_verified"]]]]]);
      Z([3,'mid-content']);
      Z([3,'qrBox']);
      Z([3,'qr-code-img']);
      Z([3,'aspectFit']);
      Z([[7],[3,"QRCodes"]]);
      Z([3,'footer']);
      Z([3,'detail']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"card_information"]]]]);
      Z([[2,"==="], [[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"lang"]]], [1,"አማ"]]);
      Z([3,'toggleLocale']);
      Z([3,'Eng']);
      Z([3,'አማ']);
      Z([3,'logout']);
      Z([3,'log']);
      Z([3,'mini']);
      Z([3,'warn']);
      Z([11,[[12],[[6],[[7],[3,"i18n"]],[3,"t"]],[[5],[1,"logout"]]]])
    })(__MAML_GLOBAL__.ops_cached.$gma_6);
    return __MAML_GLOBAL__.ops_cached.$gma_6
  }
  function gz$gma_7(){
    if(__MAML_GLOBAL__.ops_cached.$gma_7)return __MAML_GLOBAL__.ops_cached.$gma_7
    __MAML_GLOBAL__.ops_cached.$gma_7=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'container']);
      Z([3,'head']);
      Z([[8],"title",[1,"Tap on Scan QR Code to Verify an ID"]]);
      Z([[2,"!"],[[7],[3,"complete"]]]);
      Z([3,'weui-cells__title']);
      Z([11,[[7],[3,"scan_qr_code_title"]]]);
      Z([3,'page-body']);
      Z([3,'top-content']);
      Z([3,'imageBox']);
      Z([3,'profile-pic']);
      Z([3,'aspectFill']);
      Z([[7],[3,"photo"]]);
      Z([[7],[3,"complete"]]);
      Z([3,'imageBoxComplete']);
      Z([3,'weui-cells weui-cells_after-title']);
      Z([3,'weui-cell name']);
      Z([[2,"||"],[[2,"==="], [[7],[3,"version"]], [1,"2"]],[[2,"==="], [[7],[3,"version"]], [1,"3"]]]);
      Z([3,'weui-cell__bd result']);
      Z([11,[3,'Full Name: '],[[7],[3,"fullName"]]]);
      Z([11,[3,'Date of Birth: '],[[7],[3,"dob"]],[3,' G.C']]);
      Z([11,[3,'FCN: '],[[7],[3,"fcn"]]]);
      Z([11,[3,'Gender: '],[[7],[3,"gender"]]]);
      Z([3,'details']);
      Z([[2,'?:'],[[2,"==="], [[7],[3,"verified"]], [1,true]],[1,"success"],[1,"cancel"]]);
      Z([3,'verified-txt']);
      Z([11,[[2,'?:'],[[2,"==="], [[7],[3,"verified"]], [1,true]],[[7],[3,"Verified"]],[[7],[3,"Not_verified"]]]]);
      Z([3,'btn-area']);
      Z([3,'scanCode']);
      Z([3,'scan']);
      Z([3,'primry']);
      Z([11,[[7],[3,"scan_qr_code"]]]);
      Z([3,'done']);
      Z([11,[[7],[3,"done"]]]);
      Z([3,'foot'])
    })(__MAML_GLOBAL__.ops_cached.$gma_7);
    return __MAML_GLOBAL__.ops_cached.$gma_7
  }
  function gz$gma_8(){
    if(__MAML_GLOBAL__.ops_cached.$gma_8)return __MAML_GLOBAL__.ops_cached.$gma_8
    __MAML_GLOBAL__.ops_cached.$gma_8=[];
    (function(z){
      function Z(ops){z.push(ops)}
      Z([3,'https://register.fayda.et/'])
    })(__MAML_GLOBAL__.ops_cached.$gma_8);
    return __MAML_GLOBAL__.ops_cached.$gma_8
  }
  __MAML_GLOBAL__.ops_set.$gma=z;
  __MAML_GLOBAL__.ops_init.$gma=true;
  
  var sjs_require=function(){
    var smm={}; // sjs modules map
    var smem={}; // sjs modules exports map
    return function(mp){ // module path
      if(mp[0]==='p'&&mp[1]==='_'&&f_[mp.slice(2)])return f_[mp.slice(2)];
      return function(){
        if(!smm[mp]) return undefined;
        try{
          if(!smem[mp])smem[mp]=smm[mp]();
          return smem[mp];
        }catch(e){
          e.message=e.message.replace(/sjs_/g,'');
          var t = e.stack.substring(0,e.stack.lastIndexOf(mp));
          e.stack = t.substring(0,t.lastIndexOf('\n'));
          e.stack = e.stack.replace(/\ssjs_/g,' ');
          e.stack = $gstack(e.stack);
          e.stack += '\n    at ' + mp.substring(2);
          console.error(e);
        }
      }
    }
  }()

  
  d_["./pages/detail/detail.maml"]={};
  var m0=function(e,s,r,gg){
    var z=gz$gma_1()
    var oC=_ctn("view");_setAttr(z,oC,'class',0,e,s,gg);var oD=_setAttrs(z,"swiper",["autoplay",1,"bindtap",1,"circular",2,"class",3,"duration",4,"easingFunction",5,"indicatorActiveColor",6,"indicatorColor",7,"interval",8,"vertical",9],e,s,gg);var oE=_cvn();var oF=function(oJ,oI,oH,gg){var oL=_ctn("swiper-item");var oM=_setAttrs(z,"image",["class",13,"id",1,"mode",2,"src",3],oJ,oI,gg);_ac(oL,oM);_ac(oH,oL);var oN=_ctn("swiper-item");var oO=_setAttrs(z,"image",["id",14,"mode",1,"class",3,"src",4],oJ,oI,gg);_ac(oN,oO);_ac(oH,oN);return oH;};_2(z,11,oF,e,s,gg,oE,"item","index",'*this');_ac(oD,oE);_ac(oC,oD);var oP=_setAttrs(z,"view",["bindtap",2,"class",17],e,s,gg);var oQ=_ctn("text");_setAttr(z,oQ,'class',20,e,s,gg);var oR=_o(z,21,e,s,gg);_ac(oQ,oR);_ac(oP,oQ);_ac(oC,oP);var oS=_ctn("view");_setAttr(z,oS,'class',22,e,s,gg);var oT=_ctn("view");_setAttr(z,oT,'class',23,e,s,gg);var oU=_ctn("text");_setAttr(z,oU,'class',24,e,s,gg);var oV=_o(z,25,e,s,gg);_ac(oU,oV);_ac(oT,oU);var oW=_ctn("text");_setAttr(z,oW,'class',26,e,s,gg);var oX=_o(z,27,e,s,gg);_ac(oW,oX);_ac(oT,oW);_ac(oS,oT);var oY=_ctn("View");_setAttr(z,oY,'class',28,e,s,gg);_ac(oS,oY);var oZ=_ctn("view");_setAttr(z,oZ,'class',23,e,s,gg);var oa=_ctn("text");_setAttr(z,oa,'class',24,e,s,gg);var ob=_o(z,29,e,s,gg);_ac(oa,ob);_ac(oZ,oa);var oc=_ctn("text");_setAttr(z,oc,'class',26,e,s,gg);var od=_o(z,30,e,s,gg);_ac(oc,od);_ac(oZ,oc);_ac(oS,oZ);var oe=_ctn("View");_setAttr(z,oe,'class',28,e,s,gg);_ac(oS,oe);var of=_ctn("view");_setAttr(z,of,'class',23,e,s,gg);var og=_ctn("text");_setAttr(z,og,'class',24,e,s,gg);var oh=_o(z,31,e,s,gg);_ac(og,oh);_ac(of,og);var oi=_ctn("text");_setAttr(z,oi,'class',26,e,s,gg);var oj=_o(z,32,e,s,gg);_ac(oi,oj);_ac(of,oi);_ac(oS,of);var ok=_ctn("View");_setAttr(z,ok,'class',28,e,s,gg);_ac(oS,ok);var ol=_ctn("view");_setAttr(z,ol,'class',23,e,s,gg);var om=_ctn("text");_setAttr(z,om,'class',24,e,s,gg);var on=_o(z,33,e,s,gg);_ac(om,on);_ac(ol,om);var oo=_ctn("text");_setAttr(z,oo,'class',26,e,s,gg);var op=_o(z,34,e,s,gg);_ac(oo,op);_ac(ol,oo);_ac(oS,ol);var oq=_ctn("View");_setAttr(z,oq,'class',28,e,s,gg);_ac(oS,oq);var or=_ctn("view");_setAttr(z,or,'class',23,e,s,gg);var os=_ctn("text");_setAttr(z,os,'class',24,e,s,gg);var ot=_o(z,35,e,s,gg);_ac(os,ot);_ac(or,os);var ou=_ctn("text");_setAttr(z,ou,'class',26,e,s,gg);var ov=_o(z,36,e,s,gg);_ac(ou,ov);_ac(or,ou);_ac(oS,or);var ow=_ctn("View");_setAttr(z,ow,'class',28,e,s,gg);_ac(oS,ow);var ox=_ctn("view");_setAttr(z,ox,'class',23,e,s,gg);var oy=_ctn("text");_setAttr(z,oy,'class',24,e,s,gg);var oz=_o(z,37,e,s,gg);_ac(oy,oz);_ac(ox,oy);var o_=_ctn("text");_setAttr(z,o_,'class',26,e,s,gg);var oAB=_o(z,38,e,s,gg);_ac(o_,oAB);_ac(ox,o_);_ac(oS,ox);var oBB=_ctn("View");_setAttr(z,oBB,'class',28,e,s,gg);_ac(oS,oBB);var oCB=_ctn("view");_setAttr(z,oCB,'class',23,e,s,gg);var oDB=_ctn("text");_setAttr(z,oDB,'class',24,e,s,gg);var oEB=_o(z,39,e,s,gg);_ac(oDB,oEB);_ac(oCB,oDB);var oFB=_ctn("text");_setAttr(z,oFB,'class',26,e,s,gg);var oGB=_o(z,40,e,s,gg);_ac(oFB,oGB);_ac(oCB,oFB);_ac(oS,oCB);var oHB=_ctn("View");_setAttr(z,oHB,'class',28,e,s,gg);_ac(oS,oHB);var oIB=_ctn("view");_setAttr(z,oIB,'class',23,e,s,gg);var oJB=_ctn("text");_setAttr(z,oJB,'class',24,e,s,gg);var oKB=_o(z,41,e,s,gg);_ac(oJB,oKB);_ac(oIB,oJB);var oLB=_ctn("text");_setAttr(z,oLB,'class',26,e,s,gg);var oMB=_o(z,42,e,s,gg);_ac(oLB,oMB);_ac(oIB,oLB);_ac(oS,oIB);var oNB=_ctn("View");_setAttr(z,oNB,'class',28,e,s,gg);_ac(oS,oNB);var oOB=_ctn("view");_setAttr(z,oOB,'class',23,e,s,gg);var oPB=_ctn("text");_setAttr(z,oPB,'class',24,e,s,gg);var oQB=_o(z,43,e,s,gg);_ac(oPB,oQB);_ac(oOB,oPB);var oRB=_ctn("text");_setAttr(z,oRB,'class',26,e,s,gg);var oSB=_o(z,44,e,s,gg);_ac(oRB,oSB);_ac(oOB,oRB);_ac(oS,oOB);var oTB=_ctn("View");_setAttr(z,oTB,'class',28,e,s,gg);_ac(oS,oTB);var oUB=_ctn("view");_setAttr(z,oUB,'class',23,e,s,gg);var oVB=_ctn("text");_setAttr(z,oVB,'class',24,e,s,gg);var oWB=_o(z,45,e,s,gg);_ac(oVB,oWB);_ac(oUB,oVB);var oXB=_ctn("span");_setAttr(z,oXB,'class',46,e,s,gg);var oYB=_o(z,47,e,s,gg);_ac(oXB,oYB);_ac(oUB,oXB);var oZB=_ctn("text");_setAttr(z,oZB,'class',26,e,s,gg);var oaB=_o(z,48,e,s,gg);_ac(oZB,oaB);_ac(oUB,oZB);_ac(oS,oUB);_ac(oC,oS);_ac(r,oC);
    return r;
  };
  e_["./pages/detail/detail.maml"]={f:m0,j:[],i:[],ti:[],ic:[]};

  d_["./pages/id_back/id_back.maml"]={};
  var m1=function(e,s,r,gg){
    var z=gz$gma_2()
    var ocB=_ctn("view");_setAttr(z,ocB,'class',0,e,s,gg);var odB=_ctn("view");_setAttr(z,odB,'class',1,e,s,gg);var oeB=_setAttrs(z,"image",["class",2,"mode",1,"src",2],e,s,gg);_ac(odB,oeB);_ac(ocB,odB);var ofB=_ctn("view");_setAttr(z,ofB,'class',5,e,s,gg);var ogB=_setAttrs(z,"button",["bind:tap",6,"class",1,"loading",2,"size",3],e,s,gg);var ohB=_ctn("text");var oiB=_o(z,10,e,s,gg);_ac(ohB,oiB);_ac(ogB,ohB);_ac(ofB,ogB);var ojB=_ctn("text");var okB=_o(z,11,e,s,gg);_ac(ojB,okB);_ac(ofB,ojB);var olB=_setAttrs(z,"icon",["bind:tap",12,"class",1,"color",2,"size",3,"type",4],e,s,gg);_ac(ofB,olB);_ac(ocB,ofB);_ac(r,ocB);
    return r;
  };
  e_["./pages/id_back/id_back.maml"]={f:m1,j:[],i:[],ti:[],ic:[]};

  d_["./pages/id_front/id_front.maml"]={};
  var m2=function(e,s,r,gg){
    var z=gz$gma_3()
    var onB=_ctn("view");_setAttr(z,onB,'class',0,e,s,gg);var ooB=_ctn("view");_setAttr(z,ooB,'class',1,e,s,gg);var opB=_setAttrs(z,"image",["class",2,"mode",1,"src",2],e,s,gg);_ac(ooB,opB);_ac(onB,ooB);var oqB=_ctn("view");_setAttr(z,oqB,'class',5,e,s,gg);var orB=_setAttrs(z,"button",["bind:tap",6,"class",1,"size",2],e,s,gg);var osB=_ctn("text");var otB=_o(z,9,e,s,gg);_ac(osB,otB);_ac(orB,osB);_ac(oqB,orB);var ouB=_ctn("text");var ovB=_o(z,10,e,s,gg);_ac(ouB,ovB);_ac(oqB,ouB);var owB=_setAttrs(z,"icon",["bind:tap",11,"class",1,"color",2,"size",3,"type",4],e,s,gg);_ac(oqB,owB);_ac(onB,oqB);_ac(r,onB);
    return r;
  };
  e_["./pages/id_front/id_front.maml"]={f:m2,j:[],i:[],ti:[],ic:[]};

  d_["./pages/index/index.maml"]={};
  var m3=function(e,s,r,gg){
    var z=gz$gma_4()
    var oyB=_setAttrs(z,"view",["class",0,"style",1],e,s,gg);var ozB=_cvn();if(_o(z,2,e,s,gg)){ozB.maVkey=1;var oBC=_setAttrs(z,"button",["bindtap",3,"style",1],e,s,gg);var oCC=_o(z,5,e,s,gg);_ac(oBC,oCC);_ac(ozB,oBC);var oDC=_setAttrs(z,"image",["mode",6,"src",1,"style",2],e,s,gg);_ac(ozB,oDC);var oEC=_cvn();if(_o(z,9,e,s,gg)){oEC.maVkey=1;var oFC=_setAttrs(z,"button",["bind:tap",10,"hoverStopPropagation",1,"loading",2,"style",3,"type",4],e,s,gg);var oHC=_o(z,15,e,s,gg);_ac(oFC,oHC);_ac(oEC,oFC);}else{oEC.maVkey=2;var oKC=_setAttrs(z,"form",["bindsubmit",16,"class",1,"id",2,"style",3],e,s,gg);var oLC=_setAttrs(z,"view",["class",20,"style",1],e,s,gg);var oMC=_ctn("text");_setAttr(z,oMC,'style',22,e,s,gg);var oNC=_o(z,23,e,s,gg);_ac(oMC,oNC);_ac(oLC,oMC);var oOC=_ctn("view");_setAttr(z,oOC,'class',24,e,s,gg);var oPC=_ctn("text");_setAttr(z,oPC,'class',25,e,s,gg);var oQC=_o(z,26,e,s,gg);_ac(oPC,oQC);_ac(oOC,oPC);var oRC=_setAttrs(z,"icon",["bindtap",27,"class",1,"size",2,"type",3],e,s,gg);_ac(oOC,oRC);_ac(oLC,oOC);_ac(oKC,oLC);var oSC=_ctn("view");_setAttr(z,oSC,'class',31,e,s,gg);var oTC=_ctn("view");_setAttr(z,oTC,'class',32,e,s,gg);var oUC=_ctn("view");_setAttr(z,oUC,'class',33,e,s,gg);var oVC=_o(z,34,e,s,gg);_ac(oUC,oVC);_ac(oTC,oUC);_ac(oSC,oTC);_ac(oKC,oSC);var oWC=_setAttrs(z,"view",["class",35,"style",1],e,s,gg);var oXC=_setAttrs(z,"input",["bindinput",37,"class",1,"maxlength",2,"name",3,"placeholder",4,"type",5],e,s,gg);_ac(oWC,oXC);_ac(oKC,oWC);_ac(oEC,oKC);var oYC=_ctn("view");_setAttr(z,oYC,'class',43,e,s,gg);var oZC=_ctn("view");_setAttr(z,oZC,'class',44,e,s,gg);var oaC=_setAttrs(z,"button",["bindsubmit",11,"class",34,"formType",35,"loading",36],e,s,gg);var obC=_ctn("text");_setAttr(z,obC,'class',48,e,s,gg);var ocC=_o(z,49,e,s,gg);_ac(obC,ocC);_ac(oaC,obC);_ac(oZC,oaC);_ac(oYC,oZC);var odC=_ctn("view");_setAttr(z,odC,'class',50,e,s,gg);var oeC=_setAttrs(z,"button",["bindtap",51,"class",1],e,s,gg);var ofC=_ctn("text");_setAttr(z,ofC,'class',53,e,s,gg);var ogC=_o(z,54,e,s,gg);_ac(ofC,ogC);_ac(oeC,ofC);_ac(odC,oeC);_ac(oYC,odC);_ac(oEC,oYC);}_ac(ozB,oEC);var ohC=_cvn();if(_o(z,9,e,s,gg)){ohC.maVkey=1;var oiC=_ctn("view");_setAttr(z,oiC,'class',55,e,s,gg);var okC=_cvn();if(_o(z,56,e,s,gg)){okC.maVkey=1;var olC=_ctn("view");_setAttr(z,olC,'class',57,e,s,gg);var onC=_ctn("text");_setAttr(z,onC,'class',58,e,s,gg);var ooC=_o(z,59,e,s,gg);_ac(onC,ooC);_ac(olC,onC);var opC=_ctn("text");_setAttr(z,opC,'class',60,e,s,gg);var oqC=_o(z,61,e,s,gg);_ac(opC,oqC);_ac(olC,opC);_ac(okC,olC);} _ac(oiC,okC);var orC=_cvn();if(_o(z,62,e,s,gg)){orC.maVkey=1;var osC=_ctn("view");_setAttr(z,osC,'class',63,e,s,gg);var ouC=_ctn("text");_setAttr(z,ouC,'class',58,e,s,gg);var ovC=_o(z,64,e,s,gg);_ac(ouC,ovC);_ac(osC,ouC);_ac(orC,osC);} _ac(oiC,orC);var owC=_setAttrs(z,"button",["bind:tap",65,"class",1],e,s,gg);var oxC=_ctn("text");_setAttr(z,oxC,'class',67,e,s,gg);var oyC=_o(z,68,e,s,gg);_ac(oxC,oyC);_ac(owC,oxC);_ac(oiC,owC);_ac(ohC,oiC);} _ac(ozB,ohC);var ozC=_cvn();if(_o(z,56,e,s,gg)){ozC.maVkey=1;var o_C=_ctn("view");_setAttr(z,o_C,'class',55,e,s,gg);var oBD=_ctn("view");_setAttr(z,oBD,'class',57,e,s,gg);var oCD=_ctn("text");_setAttr(z,oCD,'class',58,e,s,gg);var oDD=_o(z,59,e,s,gg);_ac(oCD,oDD);_ac(oBD,oCD);var oED=_ctn("text");_setAttr(z,oED,'class',60,e,s,gg);var oFD=_o(z,61,e,s,gg);_ac(oED,oFD);_ac(oBD,oED);_ac(o_C,oBD);var oGD=_setAttrs(z,"button",["bind:tap",65,"class",4],e,s,gg);var oHD=_ctn("text");_setAttr(z,oHD,'class',70,e,s,gg);var oID=_o(z,68,e,s,gg);_ac(oHD,oID);_ac(oGD,oHD);_ac(o_C,oGD);_ac(ozC,o_C);} _ac(ozB,ozC);} _ac(oyB,ozB);var oJD=_cvn();if(_o(z,71,e,s,gg)){oJD.maVkey=1;var oMD=_setAttrs(z,"button",["bindtap",3,"style",1],e,s,gg);var oND=_o(z,72,e,s,gg);_ac(oMD,oND);_ac(oJD,oMD);var oOD=_setAttrs(z,"image",["mode",6,"src",1,"style",2],e,s,gg);_ac(oJD,oOD);var oPD=_cvn();if(_o(z,9,e,s,gg)){oPD.maVkey=1;var oQD=_setAttrs(z,"button",["bind:tap",10,"hoverStopPropagation",1,"loading",2,"style",3,"type",4],e,s,gg);var oSD=_o(z,15,e,s,gg);_ac(oQD,oSD);_ac(oPD,oQD);}else{oPD.maVkey=2;var oVD=_setAttrs(z,"form",["bindsubmit",16,"class",1,"id",2,"style",3],e,s,gg);var oWD=_ctn("view");_setAttr(z,oWD,'class',20,e,s,gg);var oXD=_setAttrs(z,"text",["style",22,"class",51],e,s,gg);var oYD=_o(z,23,e,s,gg);_ac(oXD,oYD);_ac(oWD,oXD);var oZD=_ctn("view");_setAttr(z,oZD,'class',24,e,s,gg);var oaD=_ctn("text");_setAttr(z,oaD,'class',73,e,s,gg);var obD=_o(z,26,e,s,gg);_ac(oaD,obD);_ac(oZD,oaD);var ocD=_setAttrs(z,"icon",["bindtap",27,"class",1,"size",2,"type",3],e,s,gg);_ac(oZD,ocD);_ac(oWD,oZD);_ac(oVD,oWD);var odD=_ctn("view");_setAttr(z,odD,'class',31,e,s,gg);var oeD=_ctn("view");_setAttr(z,oeD,'class',32,e,s,gg);var ofD=_ctn("view");_setAttr(z,ofD,'class',33,e,s,gg);var ogD=_o(z,34,e,s,gg);_ac(ofD,ogD);_ac(oeD,ofD);_ac(odD,oeD);_ac(oVD,odD);var ohD=_setAttrs(z,"view",["class",35,"style",1],e,s,gg);var oiD=_setAttrs(z,"input",["bindinput",37,"class",1,"maxlength",2,"name",3,"placeholder",4,"type",5],e,s,gg);_ac(ohD,oiD);_ac(oVD,ohD);_ac(oPD,oVD);var ojD=_ctn("view");_setAttr(z,ojD,'class',43,e,s,gg);var okD=_ctn("view");_setAttr(z,okD,'class',44,e,s,gg);var olD=_setAttrs(z,"button",["bindsubmit",11,"class",34,"formType",35,"loading",36],e,s,gg);var omD=_ctn("text");_setAttr(z,omD,'class',48,e,s,gg);var onD=_o(z,49,e,s,gg);_ac(omD,onD);_ac(olD,omD);_ac(okD,olD);_ac(ojD,okD);var ooD=_ctn("view");_setAttr(z,ooD,'class',50,e,s,gg);var opD=_setAttrs(z,"button",["bindtap",51,"class",1],e,s,gg);var oqD=_ctn("text");_setAttr(z,oqD,'class',53,e,s,gg);var orD=_o(z,54,e,s,gg);_ac(oqD,orD);_ac(opD,oqD);_ac(ooD,opD);_ac(ojD,ooD);_ac(oPD,ojD);}_ac(oJD,oPD);var osD=_cvn();if(_o(z,9,e,s,gg)){osD.maVkey=1;var otD=_ctn("view");_setAttr(z,otD,'class',55,e,s,gg);var ovD=_cvn();if(_o(z,56,e,s,gg)){ovD.maVkey=1;var owD=_ctn("view");_setAttr(z,owD,'class',57,e,s,gg);var oyD=_ctn("text");_setAttr(z,oyD,'class',58,e,s,gg);var ozD=_o(z,74,e,s,gg);_ac(oyD,ozD);_ac(owD,oyD);var o_D=_ctn("text");_setAttr(z,o_D,'class',60,e,s,gg);var oAE=_o(z,61,e,s,gg);_ac(o_D,oAE);_ac(owD,o_D);_ac(ovD,owD);} _ac(otD,ovD);var oBE=_cvn();if(_o(z,62,e,s,gg)){oBE.maVkey=1;var oCE=_ctn("view");_setAttr(z,oCE,'class',63,e,s,gg);var oEE=_ctn("text");_setAttr(z,oEE,'class',58,e,s,gg);var oFE=_o(z,64,e,s,gg);_ac(oEE,oFE);_ac(oCE,oEE);_ac(oBE,oCE);} _ac(otD,oBE);var oGE=_setAttrs(z,"button",["bind:tap",65,"class",1],e,s,gg);var oHE=_ctn("text");_setAttr(z,oHE,'class',67,e,s,gg);var oIE=_o(z,68,e,s,gg);_ac(oHE,oIE);_ac(oGE,oHE);_ac(otD,oGE);_ac(osD,otD);} _ac(oJD,osD);var oJE=_cvn();if(_o(z,56,e,s,gg)){oJE.maVkey=1;var oKE=_ctn("view");_setAttr(z,oKE,'class',55,e,s,gg);var oME=_ctn("view");_setAttr(z,oME,'class',57,e,s,gg);var oNE=_ctn("text");_setAttr(z,oNE,'class',58,e,s,gg);var oOE=_o(z,74,e,s,gg);_ac(oNE,oOE);_ac(oME,oNE);var oPE=_ctn("text");_setAttr(z,oPE,'class',60,e,s,gg);var oQE=_o(z,61,e,s,gg);_ac(oPE,oQE);_ac(oME,oPE);_ac(oKE,oME);var oRE=_setAttrs(z,"button",["bind:tap",65,"class",4],e,s,gg);var oSE=_ctn("text");_setAttr(z,oSE,'class',70,e,s,gg);var oTE=_o(z,68,e,s,gg);_ac(oSE,oTE);_ac(oRE,oSE);_ac(oKE,oRE);_ac(oJE,oKE);} _ac(oJD,oJE);} _ac(oyB,oJD);_ac(r,oyB);
    return r;
  };
  e_["./pages/index/index.maml"]={f:m3,j:[],i:[],ti:[],ic:[]};

  d_["./pages/lost_uin/lost_uin.maml"]={};
  var m4=function(e,s,r,gg){
    var z=gz$gma_5()
    var oVE=_setAttrs(z,"view",["class",0,"style",1],e,s,gg);var oWE=_cvn();if(_o(z,2,e,s,gg)){oWE.maVkey=1;var oZE=_setAttrs(z,"form",["bindsubmit",3,"class",1,"id",2],e,s,gg);var oaE=_setAttrs(z,"view",["style",1,"class",5],e,s,gg);var obE=_setAttrs(z,"text",["class",7,"style",1],e,s,gg);var ocE=_o(z,9,e,s,gg);_ac(obE,ocE);_ac(oaE,obE);var odE=_setAttrs(z,"text",["class",7,"style",3],e,s,gg);var oeE=_o(z,11,e,s,gg);_ac(odE,oeE);_ac(oaE,odE);_ac(oZE,oaE);var ofE=_setAttrs(z,"view",["class",12,"style",1],e,s,gg);var ogE=_setAttrs(z,"image",["class",14,"mode",1,"src",2],e,s,gg);_ac(ofE,ogE);_ac(oZE,ofE);var ohE=_ctn("view");_setAttr(z,ohE,'class',17,e,s,gg);var oiE=_setAttrs(z,"button",["bindtap",18,"class",1],e,s,gg);var ojE=_ctn("text");_setAttr(z,ojE,'class',20,e,s,gg);var okE=_o(z,21,e,s,gg);_ac(ojE,okE);_ac(oiE,ojE);_ac(ohE,oiE);_ac(oZE,ohE);var olE=_ctn("view");_setAttr(z,olE,'style',22,e,s,gg);var omE=_setAttrs(z,"view",["style",1,"class",5],e,s,gg);var onE=_ctn("text");_setAttr(z,onE,'class',23,e,s,gg);_ac(omE,onE);var ooE=_setAttrs(z,"text",["class",7,"style",17],e,s,gg);var opE=_o(z,25,e,s,gg);_ac(ooE,opE);_ac(omE,ooE);_ac(olE,omE);var oqE=_cvn();if(_o(z,26,e,s,gg)){oqE.maVkey=1;var orE=_ctn("view");_setAttr(z,orE,'class',27,e,s,gg);var otE=_ctn("view");_setAttr(z,otE,'class',28,e,s,gg);var ouE=_ctn("text");_setAttr(z,ouE,'class',29,e,s,gg);var ovE=_o(z,30,e,s,gg);_ac(ouE,ovE);_ac(otE,ouE);var owE=_ctn("text");_setAttr(z,owE,'class',31,e,s,gg);var oxE=_o(z,32,e,s,gg);_ac(owE,oxE);_ac(otE,owE);_ac(orE,otE);_ac(oqE,orE);}else if(_o(z,33,e,s,gg)){oqE.maVkey=2;var oyE=_ctn("view");_setAttr(z,oyE,'class',34,e,s,gg);var o_E=_ctn("view");_setAttr(z,o_E,'class',35,e,s,gg);var oAF=_ctn("text");_setAttr(z,oAF,'class',29,e,s,gg);var oBF=_o(z,36,e,s,gg);_ac(oAF,oBF);_ac(o_E,oAF);var oCF=_ctn("text");_setAttr(z,oCF,'class',31,e,s,gg);var oDF=_o(z,37,e,s,gg);_ac(oCF,oDF);_ac(o_E,oCF);_ac(oyE,o_E);_ac(oqE,oyE);}else if(_o(z,38,e,s,gg)){oqE.maVkey=3;var oEF=_ctn("view");_setAttr(z,oEF,'class',34,e,s,gg);var oGF=_ctn("view");_setAttr(z,oGF,'class',35,e,s,gg);var oHF=_ctn("text");_setAttr(z,oHF,'class',29,e,s,gg);var oIF=_o(z,39,e,s,gg);_ac(oHF,oIF);_ac(oGF,oHF);var oJF=_ctn("text");_setAttr(z,oJF,'class',31,e,s,gg);var oKF=_o(z,40,e,s,gg);_ac(oJF,oKF);_ac(oGF,oJF);_ac(oEF,oGF);_ac(oqE,oEF);}else if(_o(z,41,e,s,gg)){oqE.maVkey=4;var oLF=_ctn("view");_setAttr(z,oLF,'class',34,e,s,gg);var oNF=_ctn("view");_setAttr(z,oNF,'class',35,e,s,gg);var oOF=_ctn("text");_setAttr(z,oOF,'class',29,e,s,gg);var oPF=_o(z,42,e,s,gg);_ac(oOF,oPF);_ac(oNF,oOF);var oQF=_ctn("text");_setAttr(z,oQF,'class',31,e,s,gg);var oRF=_o(z,43,e,s,gg);_ac(oQF,oRF);_ac(oNF,oQF);_ac(oLF,oNF);_ac(oqE,oLF);}else if(_o(z,44,e,s,gg)){oqE.maVkey=5;var oSF=_ctn("view");_setAttr(z,oSF,'class',34,e,s,gg);var oUF=_ctn("view");_setAttr(z,oUF,'class',35,e,s,gg);var oVF=_ctn("text");_setAttr(z,oVF,'class',29,e,s,gg);var oWF=_o(z,45,e,s,gg);_ac(oVF,oWF);_ac(oUF,oVF);var oXF=_ctn("text");_setAttr(z,oXF,'class',31,e,s,gg);var oYF=_o(z,46,e,s,gg);_ac(oXF,oYF);_ac(oUF,oXF);_ac(oSF,oUF);_ac(oqE,oSF);} _ac(olE,oqE);var oZF=_ctn("view");_setAttr(z,oZF,'class',47,e,s,gg);var oaF=_setAttrs(z,"input",["bindinput",48,"class",1,"maxlength",2,"name",3,"placeholder",4,"type",5,"value",6],e,s,gg);_ac(oZF,oaF);_ac(olE,oZF);var obF=_setAttrs(z,"view",["class",55,"style",1],e,s,gg);var ocF=_setAttrs(z,"button",["bindsubmit",57,"formType",1,"loading",2,"style",3,"type",4],e,s,gg);var odF=_o(z,62,e,s,gg);_ac(ocF,odF);_ac(obF,ocF);_ac(olE,obF);_ac(oZE,olE);_ac(oWE,oZE);}else{oWE.maVkey=2;var ogF=_setAttrs(z,"form",["bindsubmit",3,"class",1,"id",2],e,s,gg);var ohF=_setAttrs(z,"view",["style",1,"class",5],e,s,gg);var oiF=_setAttrs(z,"text",["class",7,"style",1],e,s,gg);var ojF=_o(z,9,e,s,gg);_ac(oiF,ojF);_ac(ohF,oiF);var okF=_setAttrs(z,"text",["class",7,"style",3],e,s,gg);var olF=_o(z,11,e,s,gg);_ac(okF,olF);_ac(ohF,okF);_ac(ogF,ohF);var omF=_setAttrs(z,"view",["class",12,"style",1],e,s,gg);var onF=_setAttrs(z,"image",["class",14,"mode",1,"src",2],e,s,gg);_ac(omF,onF);_ac(ogF,omF);var ooF=_ctn("view");_setAttr(z,ooF,'class',17,e,s,gg);var opF=_setAttrs(z,"button",["bindtap",18,"class",1],e,s,gg);var oqF=_ctn("text");_setAttr(z,oqF,'class',20,e,s,gg);var orF=_o(z,21,e,s,gg);_ac(oqF,orF);_ac(opF,oqF);_ac(ooF,opF);_ac(ogF,ooF);var osF=_ctn("view");_setAttr(z,osF,'style',22,e,s,gg);var otF=_setAttrs(z,"view",["style",1,"class",5],e,s,gg);var ouF=_ctn("text");_setAttr(z,ouF,'class',23,e,s,gg);_ac(otF,ouF);var ovF=_setAttrs(z,"text",["class",7,"style",17],e,s,gg);var owF=_o(z,25,e,s,gg);_ac(ovF,owF);_ac(otF,ovF);_ac(osF,otF);var oxF=_cvn();if(_o(z,26,e,s,gg)){oxF.maVkey=1;var oyF=_ctn("view");_setAttr(z,oyF,'class',27,e,s,gg);var o_F=_ctn("view");_setAttr(z,o_F,'class',63,e,s,gg);var oAG=_ctn("text");_setAttr(z,oAG,'class',29,e,s,gg);var oBG=_o(z,30,e,s,gg);_ac(oAG,oBG);_ac(o_F,oAG);var oCG=_ctn("text");_setAttr(z,oCG,'class',31,e,s,gg);var oDG=_o(z,32,e,s,gg);_ac(oCG,oDG);_ac(o_F,oCG);_ac(oyF,o_F);_ac(oxF,oyF);}else if(_o(z,33,e,s,gg)){oxF.maVkey=2;var oEG=_ctn("view");_setAttr(z,oEG,'class',34,e,s,gg);var oGG=_ctn("view");_setAttr(z,oGG,'class',35,e,s,gg);var oHG=_ctn("text");_setAttr(z,oHG,'class',29,e,s,gg);var oIG=_o(z,36,e,s,gg);_ac(oHG,oIG);_ac(oGG,oHG);var oJG=_ctn("text");_setAttr(z,oJG,'class',31,e,s,gg);var oKG=_o(z,37,e,s,gg);_ac(oJG,oKG);_ac(oGG,oJG);_ac(oEG,oGG);_ac(oxF,oEG);}else if(_o(z,38,e,s,gg)){oxF.maVkey=3;var oLG=_ctn("view");_setAttr(z,oLG,'class',34,e,s,gg);var oNG=_ctn("view");_setAttr(z,oNG,'class',35,e,s,gg);var oOG=_ctn("text");_setAttr(z,oOG,'class',29,e,s,gg);var oPG=_o(z,39,e,s,gg);_ac(oOG,oPG);_ac(oNG,oOG);var oQG=_ctn("text");_setAttr(z,oQG,'class',31,e,s,gg);var oRG=_o(z,40,e,s,gg);_ac(oQG,oRG);_ac(oNG,oQG);_ac(oLG,oNG);_ac(oxF,oLG);}else if(_o(z,41,e,s,gg)){oxF.maVkey=4;var oSG=_ctn("view");_setAttr(z,oSG,'class',34,e,s,gg);var oUG=_ctn("view");_setAttr(z,oUG,'class',35,e,s,gg);var oVG=_ctn("text");_setAttr(z,oVG,'class',29,e,s,gg);var oWG=_o(z,42,e,s,gg);_ac(oVG,oWG);_ac(oUG,oVG);var oXG=_ctn("text");_setAttr(z,oXG,'class',31,e,s,gg);var oYG=_o(z,43,e,s,gg);_ac(oXG,oYG);_ac(oUG,oXG);_ac(oSG,oUG);_ac(oxF,oSG);}else if(_o(z,44,e,s,gg)){oxF.maVkey=5;var oZG=_ctn("view");_setAttr(z,oZG,'class',34,e,s,gg);var obG=_ctn("view");_setAttr(z,obG,'class',35,e,s,gg);var ocG=_ctn("text");_setAttr(z,ocG,'class',29,e,s,gg);var odG=_o(z,45,e,s,gg);_ac(ocG,odG);_ac(obG,ocG);var oeG=_ctn("text");_setAttr(z,oeG,'class',31,e,s,gg);var ofG=_o(z,46,e,s,gg);_ac(oeG,ofG);_ac(obG,oeG);_ac(oZG,obG);_ac(oxF,oZG);} _ac(osF,oxF);var ogG=_ctn("view");_setAttr(z,ogG,'class',47,e,s,gg);var ohG=_setAttrs(z,"input",["bindinput",48,"class",1,"maxlength",2,"name",3,"placeholder",4,"type",5,"value",6],e,s,gg);_ac(ogG,ohG);_ac(osF,ogG);var oiG=_setAttrs(z,"view",["class",55,"style",1],e,s,gg);var ojG=_setAttrs(z,"button",["bindsubmit",57,"formType",1,"loading",2,"style",3,"type",4],e,s,gg);var okG=_o(z,62,e,s,gg);_ac(ojG,okG);_ac(oiG,ojG);_ac(osF,oiG);_ac(ogF,osF);_ac(oWE,ogF);}_ac(oVE,oWE);_ac(r,oVE);
    return r;
  };
  e_["./pages/lost_uin/lost_uin.maml"]={f:m4,j:[],i:[],ti:[],ic:[]};

  d_["./pages/profile/profile.maml"]={};
  var m5=function(e,s,r,gg){
    var z=gz$gma_6()
    var omG=_ctn("view");_setAttr(z,omG,'class',0,e,s,gg);var onG=_ctn("view");_setAttr(z,onG,'class',1,e,s,gg);var ooG=_ctn("view");_setAttr(z,ooG,'class',2,e,s,gg);var opG=_setAttrs(z,"image",["class",3,"mode",1,"src",2],e,s,gg);_ac(ooG,opG);_ac(onG,ooG);var oqG=_ctn("text");_setAttr(z,oqG,'class',6,e,s,gg);var orG=_o(z,7,e,s,gg);_ac(oqG,orG);_ac(onG,oqG);var osG=_ctn("view");_setAttr(z,osG,'class',8,e,s,gg);var otG=_ctn("icon");_setAttr(z,otG,'type',9,e,s,gg);_ac(osG,otG);var ouG=_ctn("text");_setAttr(z,ouG,'class',10,e,s,gg);var ovG=_o(z,11,e,s,gg);_ac(ouG,ovG);_ac(osG,ouG);_ac(onG,osG);_ac(omG,onG);var owG=_ctn("view");_setAttr(z,owG,'class',12,e,s,gg);var oxG=_ctn("view");_setAttr(z,oxG,'class',13,e,s,gg);var oyG=_setAttrs(z,"image",["class",14,"mode",1,"src",2],e,s,gg);_ac(oxG,oyG);_ac(owG,oxG);_ac(omG,owG);var ozG=_ctn("view");_setAttr(z,ozG,'class',17,e,s,gg);var o_G=_ctn("button");_setAttr(z,o_G,'bind:tap',18,e,s,gg);var oAH=_ctn("text");var oBH=_o(z,19,e,s,gg);_ac(oAH,oBH);_ac(o_G,oAH);_ac(ozG,o_G);_ac(omG,ozG);var oCH=_cvn();if(_o(z,20,e,s,gg)){oCH.maVkey=1;var oFH=_ctn("button");_setAttr(z,oFH,'bindtap',21,e,s,gg);var oGH=_o(z,22,e,s,gg);_ac(oFH,oGH);_ac(oCH,oFH);}else{oCH.maVkey=2;var oJH=_ctn("button");_setAttr(z,oJH,'bindtap',21,e,s,gg);var oKH=_o(z,23,e,s,gg);_ac(oJH,oKH);_ac(oCH,oJH);}_ac(omG,oCH);var oLH=_setAttrs(z,"button",["bind:tap",24,"class",1,"size",2,"type",3],e,s,gg);var oMH=_ctn("text");var oNH=_o(z,28,e,s,gg);_ac(oMH,oNH);_ac(oLH,oMH);_ac(omG,oLH);_ac(r,omG);
    return r;
  };
  e_["./pages/profile/profile.maml"]={f:m5,j:[],i:[],ti:[],ic:[]};

  d_["./pages/qrcode/qrcode.maml"]={};
  var m6=function(e,s,r,gg){
    var z=gz$gma_7()
    var oOH=e_["./pages/qrcode/qrcode.maml"].i;_ai(oOH,'../qrcode/head.maml',e_,'./pages/qrcode/qrcode.maml',0,0);_ai(oOH,'../qrcode/foot.maml',e_,'./pages/qrcode/qrcode.maml',0,0);var oRH=_ctn("view");_setAttr(z,oRH,'class',0,e,s,gg);var oSH=_cvn();
    var oTH=_o(z,1,e,s,gg);
    var oUH=_gd('./pages/qrcode/qrcode.maml',oTH,e_,d_);
    if(oUH){
      var oVH=_1(z,2,e,s,gg);
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oUH(oVH,oVH,oSH,gg);
      gg.f=tgf;
    }else{
      _w(oTH,'./pages/qrcode/qrcode.maml',0,0);
    }
    _ac(oRH,oSH);var oWH=_cvn();if(_o(z,3,e,s,gg)){oWH.maVkey=1;var oXH=_ctn("view");_setAttr(z,oXH,'class',4,e,s,gg);var oZH=_o(z,5,e,s,gg);_ac(oXH,oZH);_ac(oWH,oXH);} _ac(oRH,oWH);var oaH=_ctn("view");_setAttr(z,oaH,'class',6,e,s,gg);var obH=_ctn("view");_setAttr(z,obH,'class',7,e,s,gg);var ocH=_cvn();if(_o(z,3,e,s,gg)){ocH.maVkey=1;var odH=_ctn("view");_setAttr(z,odH,'class',8,e,s,gg);var ofH=_setAttrs(z,"image",["class",9,"mode",1,"src",2],e,s,gg);_ac(odH,ofH);_ac(ocH,odH);} _ac(obH,ocH);var ogH=_cvn();if(_o(z,12,e,s,gg)){ogH.maVkey=1;var ohH=_ctn("view");_setAttr(z,ohH,'class',13,e,s,gg);var ojH=_setAttrs(z,"image",["class",9,"mode",1,"src",2],e,s,gg);_ac(ohH,ojH);_ac(ogH,ohH);} _ac(obH,ogH);_ac(oaH,obH);var okH=_ctn("view");_setAttr(z,okH,'class',14,e,s,gg);var olH=_cvn();if(_o(z,12,e,s,gg)){olH.maVkey=1;var omH=_ctn("view");_setAttr(z,omH,'class',15,e,s,gg);var ooH=_cvn();if(_o(z,16,e,s,gg)){ooH.maVkey=1;var orH=_ctn("view");_setAttr(z,orH,'class',17,e,s,gg);var osH=_o(z,18,e,s,gg);_ac(orH,osH);_ac(ooH,orH);var otH=_ctn("view");_setAttr(z,otH,'class',17,e,s,gg);var ouH=_o(z,19,e,s,gg);_ac(otH,ouH);_ac(ooH,otH);var ovH=_ctn("view");_setAttr(z,ovH,'class',17,e,s,gg);var owH=_o(z,20,e,s,gg);_ac(ovH,owH);_ac(ooH,ovH);var oxH=_ctn("view");_setAttr(z,oxH,'class',17,e,s,gg);var oyH=_o(z,21,e,s,gg);_ac(oxH,oyH);_ac(ooH,oxH);}else{ooH.maVkey=2;var oAI=_ctn("view");_setAttr(z,oAI,'class',17,e,s,gg);var oBI=_o(z,18,e,s,gg);_ac(oAI,oBI);_ac(ooH,oAI);}_ac(omH,ooH);var oCI=_ctn("view");_setAttr(z,oCI,'class',22,e,s,gg);var oDI=_ctn("icon");_setAttr(z,oDI,'type',23,e,s,gg);_ac(oCI,oDI);var oEI=_ctn("text");_setAttr(z,oEI,'class',24,e,s,gg);var oFI=_o(z,25,e,s,gg);_ac(oEI,oFI);_ac(oCI,oEI);_ac(omH,oCI);_ac(olH,omH);} _ac(okH,olH);_ac(oaH,okH);var oGI=_ctn("view");_setAttr(z,oGI,'class',26,e,s,gg);var oHI=_cvn();if(_o(z,3,e,s,gg)){oHI.maVkey=1;var oII=_setAttrs(z,"button",["bindtap",27,"class",1,"type",2],e,s,gg);var oKI=_o(z,30,e,s,gg);_ac(oII,oKI);_ac(oHI,oII);} _ac(oGI,oHI);_ac(oaH,oGI);var oLI=_ctn("view");_setAttr(z,oLI,'class',26,e,s,gg);var oMI=_cvn();if(_o(z,12,e,s,gg)){oMI.maVkey=1;var oNI=_setAttrs(z,"button",["class",28,"type",1,"bindtap",3],e,s,gg);var oPI=_o(z,32,e,s,gg);_ac(oNI,oPI);_ac(oMI,oNI);} _ac(oLI,oMI);_ac(oaH,oLI);_ac(oRH,oaH);var oQI=_cvn();
    var oRI=_o(z,33,e,s,gg);
    var oSI=_gd('./pages/qrcode/qrcode.maml',oRI,e_,d_);
    if(oSI){
      var oTI={};
      var tgf=gg.f; // template will overwrite gg.f, so need to back up
      oSI(oTI,oTI,oQI,gg);
      gg.f=tgf;
    }else{
      _w(oRI,'./pages/qrcode/qrcode.maml',0,0);
    }
    _ac(oRH,oQI);_ac(r,oRH);oOH.pop();oOH.pop();
    return r;
  };
  e_["./pages/qrcode/qrcode.maml"]={f:m6,j:[],i:[],ti:["../qrcode/head.maml","../qrcode/foot.maml"],ic:[]};

  d_["./pages/registration/registration.maml"]={};
  var m7=function(e,s,r,gg){
    var z=gz$gma_8()
    var oVI=_ctn("web-view");_setAttr(z,oVI,'src',0,e,s,gg);_ac(r,oVI);
    return r;
  };
  e_["./pages/registration/registration.maml"]={f:m7,j:[],i:[],ti:[],ic:[]};

  if(path&&e_[path]){
    return function(env,dd,global){
      $gmac=0;
      var root={"tag":"ma-page","children":[]};
      var main=e_[path].f;
      if(typeof global==="undefined")global={};
      global.f=$gdc(f_[path],"",1)||{};
      global.f.i18n=f_['i18n']
      if(window.__mergeData__)env=window.__mergeData__(env,dd);
      try{
        main(env,{},root,global);
      }catch(e){
        console.log(e)
      }
      return root;
    }
  }
}

__maAppCode__['app.json']={"pages":["pages/index/index","pages/profile/profile","pages/detail/detail","pages/id_front/id_front","pages/id_back/id_back","pages/registration/registration","pages/qrcode/qrcode","pages/lost_uin/lost_uin"],"window":{"backgroundTextStyle":"dark","navigationBarBackgroundColor":"#ffffff","navigationBarTitleText":"","navigationBarTextStyle":"black","capsuleTheme":"light"},"style":"v2","sitemapLocation":"sitemap.json","tabBar":{"color":"#6b6b6b","selectedColor":"#47f4c7","backgroundColor":"#ffffff","borderStyle":"white","list":[{"pagePath":"pages/index/index","iconPath":"images/icon_component.png","selectedIconPath":"images/icon_component_HL.png","text":"ዋና ገጽ"},{"pagePath":"pages/qrcode/qrcode","iconPath":"images/icon_API.png","selectedIconPath":"images/icon_API_HL.png","text":"ማረጋገጫ"}]},"entryPagePath":"pages/index/index"};
__maAppCode__['pages/detail/detail.maml']=$gma('./pages/detail/detail.maml');
__maAppCode__['pages/detail/detail.json']={"navigationBarTitleText":"Card Information"};
__maAppCode__['pages/id_back/id_back.maml']=$gma('./pages/id_back/id_back.maml');
__maAppCode__['pages/id_back/id_back.json']={"navigationBarTitleText":"Digital ID"};
__maAppCode__['pages/id_front/id_front.maml']=$gma('./pages/id_front/id_front.maml');
__maAppCode__['pages/id_front/id_front.json']={"navigationBarTitleText":"Digital ID"};
__maAppCode__['pages/index/index.maml']=$gma('./pages/index/index.maml');
__maAppCode__['pages/index/index.json']={"usingComponents":{}};
__maAppCode__['pages/lost_uin/lost_uin.maml']=$gma('./pages/lost_uin/lost_uin.maml');
__maAppCode__['pages/lost_uin/lost_uin.json']={"navigationBarTitleText":"SMS Resend"};
__maAppCode__['pages/profile/profile.maml']=$gma('./pages/profile/profile.maml');
__maAppCode__['pages/profile/profile.json']={"navigationBarTitleText":"National ID"};
__maAppCode__['pages/qrcode/qrcode.maml']=$gma('./pages/qrcode/qrcode.maml');
__maAppCode__['pages/qrcode/qrcode.json']={"navigationBarTitleText":"Verify"};
__maAppCode__['pages/registration/registration.maml']=$gma('./pages/registration/registration.maml');
__maAppCode__['pages/registration/registration.json']={"navigationBarTitleText":"Preregistration","enablePullDownRefresh":false};

define("app.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
initI18n({defaultLocale:"am-ET"});let e="";const t=getI18nInstance();App({onLaunch:function(){e=t.getLocale(),t.onLocaleChange((a=>{e=a,ma.setTabBarItem({index:0,text:t.t("Home")}),ma.setTabBarItem({index:1,text:t.t("Verify")})})),ma.getScreenBrightness({success:e=>{}})},onReady(){t.onLocaleChange((e=>{t.setLocale(e.data)}))}});
});
define("pages/detail/detail.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({data:{src:"",srcback:"",fullName_eng:"",fullName_amh:"",email:"",dob_eng:"",dob_amh:"",sex_eng:"",sex_amh:"",age:"",phone:"",woreda_eng:"",woreda_amh:"",zone_eng:"",zone_amh:"",region_eng:"",region_amh:"",citizenship_Eng:"",citizenship_amh:"",fronts:"",backs:"",cardSide:"front",indicatorDots:!0,background:["demo-text-1"],indicatorActiveColor:"#000000",indicatorColor:"rgba(0, 0, 0, .3)",autoplay:!0,interval:2e3,duration:500,essentialFunction:"default",circular:!0,vertical:!1},clickButton:function(){ma.navigateTo({url:"../id_front/id_front"})},changeIndicatorDots:function(a){this.setData({indicatorDots:!this.data.indicatorDots})},changeAutoplay:function(a){this.setData({autoplay:!this.data.autoplay})},intervalChange:function(a){this.setData({interval:a.detail.value})},durationChange:function(a){this.setData({duration:a.detail.value})},async onLoad(){await ma.getStorage({key:"data",success(a){this.data.fullName_eng=a.data.data.data.fullName_eng,this.data.fullName_amh=a.data.data.data.fullName_amh,this.data.dob_eng=a.data.data.data.dateOfBirth_eng,this.data.dob_et=a.data.data.data.dateOfBirth_et,this.data.sex_eng=a.data.data.data.gender_eng,this.data.sex_amh=a.data.data.data.gender_amh,this.data.phone=a.data.data.data.phone,this.data.zone_eng=a.data.data.data.zone_eng,this.data.zone_amh=a.data.data.data.zone_amh,this.data.woreda_eng=a.data.data.data.woreda_eng,this.data.woreda_amh=a.data.data.data.woreda_amh,this.data.region_eng=a.data.data.data.region_eng,this.data.region_amh=a.data.data.data.region_amh,this.data.citizenship_Eng=a.data.data.data.citizenship_Eng,this.data.citizenship_amh=a.data.data.data.citizenship_amh,this.data.fronts="data:image/png;base64, "+a.data.data.data.fronts,this.data.backs="data:image/png;base64, "+a.data.data.data.backs,this.setData({fullName_eng:this.data.fullName_eng,fullName_amh:this.data.fullName_amh,dob_et:this.data.dob_et,dob_eng:this.data.dob_eng,sex_eng:this.data.sex_eng,sex_amh:this.data.sex_amh,phone:this.data.phone,zone_eng:this.data.zone_eng,zone_amh:this.data.zone_amh,subcity:this.data.subcity,region_eng:this.data.region_eng,region_amh:this.data.region_amh,woreda_eng:this.data.woreda_eng,woreda_amh:this.data.woreda_amh,citizenship_Eng:this.data.citizenship_Eng,citizenship_amh:this.data.citizenship_amh,fronts:this.data.fronts,backs:this.data.backs})}})}});
});
define("pages/id_back/id_back.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
t=getI18nInstance(),Page({data:{backs:"",accessToken:{},uin:"",id_url:"https://id.et",baseUrl:"https://mobile-mini.fayda.et",faydaPK:"-----BEGIN PUBLIC KEY-----\n    MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1GA1uSC0v6kbjiybvHmJ\n    Kpuxi4t7zSk11dbnISMrTQKQg9KJSamAtxrursm1TmV9ooUWVrMY8WC/6IljM9Gt\n    NroQOYUCzijpGTzgvrJKU85KkkRvWJ503SvujPJc3hX/KG392C4F2qREmHp77tzi\n    sZrB2MdDCCGEgrY9UoOqY9bLUfWsSx71rqx0yIB1AQYTn0C32tOhCINaXsGWA+7I\n    NJb1aOyOHmcNhI+DHDDi2K11z/nIV9lECpGIjSAhAgdDIDxoMJBcGIBSIgFdgjWI\n    aqw6cYCD5/mTTsVnu7WUaYPTAHjn+xmz+S0i1xHRIv5i/hV14DMqI7vv6YeKMbTq\n    LQIDAQAB\n    -----END PUBLIC KEY-----  \n    ",season_expired_title:"",season_expired_description:"",logout_text:"",cancel_text:""},toggleId:function(){ma.navigateBack()},openLink:function(){ma.openUrl({url:this.data.id_url+`/getId?accesstoken=${this.data.accessToken.access_token}&refreshtoken=${this.data.accessToken.refresh_token}&uin=${this.data.uin}`})},pemToCryptoKey:async function(e){const t=e.replace(/-----BEGIN PUBLIC KEY-----/,"").replace(/-----END PUBLIC KEY-----/,"").replace(/\s+/g,""),a=Uint8Array.from(atob(t),(e=>e.charCodeAt(0)));return await crypto.subtle.importKey("spki",a,{name:"RSASSA-PKCS1-v1_5",hash:{name:"SHA-256"}},!0,["verify"])},parsePublicKey:function(e){const t=e.replace("-----BEGIN PUBLIC KEY-----","").replace("-----END PUBLIC KEY-----","").replace(/\s/g,""),a=atob(t),s=new Uint8Array(a.length);for(let n=0;n<a.length;n++)s[n]=a.charCodeAt(n);return s.buffer},arrayBufferToBase64:function(e){const t=String.fromCharCode.apply(null,new Uint8Array(e));return btoa(t)},encryptData:async function(e,t){const a=crypto.getRandomValues(new Uint8Array(32)),s=(this.arrayBufferToBase64(a),e.replace(/-----BEGIN PUBLIC KEY-----/,"").replace(/-----END PUBLIC KEY-----/,"").replace(/\s+/g,"")),n=Uint8Array.from(atob(s),(e=>e.charCodeAt(0))),c=await crypto.subtle.importKey("spki",n,{name:"RSA-OAEP",hash:{name:"SHA-256"}},!1,["encrypt"]),r=await crypto.subtle.importKey("raw",a,{name:"AES-GCM"},!1,["encrypt"]),o=crypto.getRandomValues(new Uint8Array(32)),i=this.arrayBufferToBase64(o),d=await crypto.subtle.encrypt({name:"AES-GCM",iv:o},r,(new TextEncoder).encode(t)),l=await crypto.subtle.encrypt({name:"RSA-OAEP"},c,a),u=this.arrayBufferToBase64(d),p=this.arrayBufferToBase64(l);return encryptedString=`${u}.${p}.${i}`,encryptedString},downloadImg:async function(){access_tokendicOrg={uin:this.data.uin,access_token:this.data.accessToken.access_token,refresh_token:this.data.accessToken.refresh_token},access_tokendic=`${access_tokendicOrg.uin}.${access_tokendicOrg.access_token}.${access_tokendicOrg.refresh_token}`,encryptedAccessToken=await this.encryptData(this.data.faydaPK,access_tokendic);const e=encodeURIComponent(encryptedAccessToken);ma.request({url:this.data.baseUrl+"/isUser",method:"GET",header:{"Content-Type":"application/json",Authorization:"Bearer "+access_tokendicOrg.access_token,"Refresh-Token":access_tokendicOrg.refresh_token},timeout:5e5,success:t=>{ma.openUrl({url:this.data.id_url+`/getId?tb=${e}`})},fail:e=>{ma.showModal({title:t.t("season_expired_title"),content:t.t("season_expired_description"),confirmText:t.t("logout_text"),cancelText:t.t("cancel_text"),success(e){if(e.confirm)ma.clearStorage({success:e=>{this.setData({key:"",data:""}),ma.reLaunch({url:"../index/index"}),ma.showModal({title:"You have logged out successfully!",cancelText:False,confirmText:"Okay"})},fail(e){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}});else if(e.cancel)return}})}})},onShow(){"en-US"===t.getLocale()?this.setData({season_expired_title:"Session Expired!",season_expired_description:"To obtain your PDF copy, please log out and log in again.",logout_text:"Log Out",cancel_text:"Cancel"}):this.setData({season_expired_title:"ጊዜው አልፎበታል!",season_expired_description:"የእርስዎን ፒዲኤፍ ቅጂ ለማግኘት፣ እባክዎ ይውጡ እና እንደገና ይግቡ።",logout_text:"ይውጡ",cancel_text:"ይቅር"})},async onLoad(){await ma.getStorage({key:"data",success(e){this.data.backs="data:image/jpg;base64, "+e.data.data.data.backs,this.data.uin=e.data.data.data.UIN,this.setData({backs:this.data.backs,uin:this.data.uin})}}),await ma.getStorage({key:"access_token",success(e){this.data.accessToken=e.data,this.setData({accessToken:this.data.accessToken})}})}});
});
define("pages/id_front/id_front.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
t=getI18nInstance(),Page({data:{fronts:"",accessToken:{},uin:"",id_url:"https://id.et",baseUrl:"https://mobile-mini.fayda.et",faydaPK:"-----BEGIN PUBLIC KEY-----\n    MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1GA1uSC0v6kbjiybvHmJ\n    Kpuxi4t7zSk11dbnISMrTQKQg9KJSamAtxrursm1TmV9ooUWVrMY8WC/6IljM9Gt\n    NroQOYUCzijpGTzgvrJKU85KkkRvWJ503SvujPJc3hX/KG392C4F2qREmHp77tzi\n    sZrB2MdDCCGEgrY9UoOqY9bLUfWsSx71rqx0yIB1AQYTn0C32tOhCINaXsGWA+7I\n    NJb1aOyOHmcNhI+DHDDi2K11z/nIV9lECpGIjSAhAgdDIDxoMJBcGIBSIgFdgjWI\n    aqw6cYCD5/mTTsVnu7WUaYPTAHjn+xmz+S0i1xHRIv5i/hV14DMqI7vv6YeKMbTq\n    LQIDAQAB\n    -----END PUBLIC KEY-----   \n    ",season_expired_title:"",season_expired_description:"",logout_text:"",cancel_text:""},toggleId:function(){ma.navigateTo({url:"../id_back/id_back"})},pemToCryptoKey:async function(e){const t=e.replace(/-----BEGIN PUBLIC KEY-----/,"").replace(/-----END PUBLIC KEY-----/,"").replace(/\s+/g,""),a=Uint8Array.from(atob(t),(e=>e.charCodeAt(0)));return await crypto.subtle.importKey("spki",a,{name:"RSASSA-PKCS1-v1_5",hash:{name:"SHA-256"}},!0,["verify"])},parsePublicKey:function(e){const t=e.replace("-----BEGIN PUBLIC KEY-----","").replace("-----END PUBLIC KEY-----","").replace(/\s/g,""),a=atob(t),n=new Uint8Array(a.length);for(let s=0;s<a.length;s++)n[s]=a.charCodeAt(s);return n.buffer},arrayBufferToBase64:function(e){const t=String.fromCharCode.apply(null,new Uint8Array(e));return btoa(t)},encryptData:async function(e,t){const a=crypto.getRandomValues(new Uint8Array(32)),n=(this.arrayBufferToBase64(a),e.replace(/-----BEGIN PUBLIC KEY-----/,"").replace(/-----END PUBLIC KEY-----/,"").replace(/\s+/g,"")),s=Uint8Array.from(atob(n),(e=>e.charCodeAt(0))),r=await crypto.subtle.importKey("spki",s,{name:"RSA-OAEP",hash:{name:"SHA-256"}},!1,["encrypt"]),o=await crypto.subtle.importKey("raw",a,{name:"AES-GCM"},!1,["encrypt"]),c=crypto.getRandomValues(new Uint8Array(32)),i=this.arrayBufferToBase64(c),d=await crypto.subtle.encrypt({name:"AES-GCM",iv:c},o,(new TextEncoder).encode(t)),l=await crypto.subtle.encrypt({name:"RSA-OAEP"},r,a),u=this.arrayBufferToBase64(d),p=this.arrayBufferToBase64(l);return encryptedString=`${u}.${p}.${i}`,encryptedString},downloadImg:async function(){access_tokendicOrg={uin:this.data.uin,access_token:this.data.accessToken.access_token,refresh_token:this.data.accessToken.refresh_token},access_tokendic=`${access_tokendicOrg.uin}.${access_tokendicOrg.access_token}.${access_tokendicOrg.refresh_token}`,encryptedAccessToken=await this.encryptData(this.data.faydaPK,access_tokendic);const e=encodeURIComponent(encryptedAccessToken);ma.request({url:this.data.baseUrl+"/isUser",method:"GET",header:{"Content-Type":"application/json",Authorization:"Bearer "+access_tokendicOrg.access_token,"Refresh-Token":access_tokendicOrg.refresh_token},timeout:5e5,success:t=>{ma.openUrl({url:this.data.id_url+`/getId?tb=${e}`})},fail:e=>{ma.showModal({title:t.t("season_expired_title"),content:t.t("season_expired_description"),confirmText:t.t("logout_text"),cancelText:t.t("cancel_text"),success(e){if(e.confirm)ma.clearStorage({success:e=>{this.setData({key:"",data:""}),ma.reLaunch({url:"../index/index"}),ma.showModal({title:"You have logged out successfully!",cancelText:False,confirmText:"Okay"})},fail(e){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}});else if(e.cancel)return}})}})},onShow(){"en-US"===t.getLocale()?this.setData({season_expired_title:"Session Expired!",season_expired_description:"To obtain your PDF copy, please log out and log in again.",logout_text:"Log Out",cancel_text:"Cancel"}):this.setData({season_expired_title:"ጊዜው አልፎበታል!",season_expired_description:"የእርስዎን ፒዲኤፍ ቅጂ ለማግኘት፣ እባክዎ ይውጡ እና እንደገና ይግቡ።",logout_text:"ይውጡ",cancel_text:"ይቅር"})},async onLoad(){await ma.getStorage({key:"data",success(e){this.data.fronts="data:image/jpg;base64, "+e.data.data.data.fronts,this.data.uin=e.data.data.data.UIN,this.setData({fronts:this.data.fronts,uin:this.data.uin})}}),await ma.getStorage({key:"access_token",success(e){this.data.accessToken=e.data,this.setData({accessToken:this.data.accessToken})}})}});
});
define("pages/index/index.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
t=getI18nInstance(),Page({data:{fullName_eng:"",locale:"am-ET",failed:!1,displayInfo:!1,title:"Enter Your Unique Fayda ID Number",inputValue:"",src:"../../images/logo.png",icon:"../../images/icon.png",getUrl:"http://172.18.12.166/get-data/?uin=",text:"sending get request to ",baseUrl:"https://mobile-mini.fayda.et",token:"",error:{},success:"",isLoading:!1,selectedWaresInfo:void 0,userData:{open_id:"",identityId:"",identityType:"CUSTOMER",walletIdentityId:"202000000000146178",identifierType:"MSISDN",identifier:"",nickName:"",status:""},accessToken:{access_token:"",token_type:"",refresh_token:""},accessTokenPersisted:{},sign_in_with_telebirr:"",enter_fayda_no_text:"",lost_fin:"",next:"",greetings:""},lostUIN:function(){ma.navigateTo({url:"../lost_uin/lost_uin"})},bindInfoDisplay:function(){this.setData({displayInfo:!this.data.displayInfo})},bindInput:function(e){e.detail.value.length;let t=e.detail.value.toString();t=t.replace(/[^0-9-]/g,""),t=t.replace(/-/g,"");let a=t.replace(/(\d{4})(?=\d)/g,"$1-");return this.setData({inputValue:t}),a},openLink:function(){ma.openUrl({url:"https://register.fayda.et"})},clickButton1:function(e){faydaNumber=e.detail.value.uin,faydaNumber.includes("-")?faydaNumber=parseInt(faydaNumber.replace(/-/g,"")):faydaNumber.includes(" ")&&(faydaNumber=parseInt(faydaNumber.replace(/\s/g,""))),ma.showModal({title:faydaNumber,showCancel:!1,confirmText:"Close"})},toggleLocale:function(){t.setLocale("am-ET"===t.getLocale()?"en-US":"am-ET"),ma.setStorage({key:"locale",data:t.getLocale()})},registerButton:function(){ma.navigateTo({url:"../registration/registration"})},clickButton:function(e){faydaNumber=e.detail.value.uin,faydaNumber.includes("-")?faydaNumber=parseInt(faydaNumber.replace(/-/g,"")):faydaNumber.includes(" ")&&(faydaNumber=parseInt(faydaNumber.replace(/\s/g,"")));var t=this;t.setData({loading_next:!0}),access_tokendic=this.data.accessToken,12==faydaNumber.toString().length?ma.request({url:this.data.baseUrl+`/get_user_data?uin=${faydaNumber}`,method:"GET",header:{"Content-Type":"application/json",Authorization:"Bearer "+access_tokendic.access_token,"Refresh-Token":access_tokendic.refresh_token},timeout:5e5,success:e=>(t.setData({loading_next:!1}),ma.showToast({title:"Successful",icon:"success",duration:500}),ma.setStorage({key:"access_token",data:this.data.accessToken}),ma.setStorage({key:"data",data:e}),JSON.stringify(e).includes('"statusCode":401')?(t.setData({loading_next:!1,failed:!0}),void ma.showModal({title:"You are not Authorized!",content:"Please make sure you logged in with the phone number that you registered with. Email us at info@id.et if you need help. Thanks.",confirmText:"Close",showCancel:!1})):JSON.stringify(e).includes('"statusCode":444')?(t.setData({loading_next:!1,failed:!0}),void ma.showModal({title:"FIN could not be Found!",content:"Click on Register to book your registration",confirmText:"Register",cancelText:"Cancel",success(e){if(e.confirm)ma.openUrl({url:"https://register.fayda.et"});else if(e.cancel)return},fail(){}})):void(JSON.stringify(e).includes('"statusCode":200')?(t.setData({loading_next:!1,failed:!0}),ma.reLaunch({url:"../profile/profile"})):ma.showModal({title:JSON.stringify(e),content:JSON.stringify(e),confirmText:"Close",showCancel:!1}))),fail:e=>(this.setData({loading_next:!1}),JSON.stringify(e).includes("401")?void ma.showModal({title:"You are not Authorized!",content:"Please make sure you logged in with the phone number that you registered with. Email us at info@id.et if you need help. Thanks.",showCancel:!1}):JSON.stringify(e).includes("444")?void ma.showModal({title:"FIN could not be Found!",content:"Click on Register to book your registration",confirmText:"Register",cancelText:"Cancel",success(e){if(e.confirm)ma.openUrl({url:"https://register.fayda.et"});else if(e.cancel)return},fail(){}}):(t.setData({loading_next:!1}),void this.setData({...this.data,error:JSON.stringify(e)})))}):t.setData({loading_next:!1})},applyH5Token(){ma.getMiniAppToken({appId:"999918777753606",success:e=>{this.setData({...this.data,isLoading:!0}),this.reqAuthToken(e.token)},fail:e=>{ma.showModal({title:"Connection Error",content:"Please Check Your Network!",showCancel:!1,confirmText:"Close",success(e){e.confirm||e.cancel}})}})},reqAuthToken(e){var t=this;t.setData({loading:!0}),ma.request({url:this.data.baseUrl+"/apply/h5token",method:"POST",header:{"Content-Type":"application/json"},data:{authToken:e},success:e=>{t.setData({loading:!1});const{open_id:a,identityId:n,identityType:i,walletIdentityId:s,identifierType:o,identifier:r,nickName:l,status:d}=e.data.content.biz_content,{access_token:c,token_type:u,refresh_token:f}=e.data.access_token;t.setData({isloading:!1,success:e.data.content.biz_content,userData:{open_id:a,identityId:n,identityType:i,walletIdentityId:s,identifier:r,nickName:l,status:d},accessToken:{access_token:c,token_type:u,refresh_token:f}}),ma.setStorage({key:"access_token",data:e.data.access_token})},fail:e=>{ma.showModal({title:"Out of service!",showCancel:!1,confirmText:"Close",success(e){e.confirm||e.cancel}}),this.setData({...this.data,error:JSON.stringify(e)})}})},onReady(){},async onLoad(){await ma.getStorage({key:"data",success(e){this.data.fullName_eng=e.data.data.data.fullName_eng,this.setData({fullName_eng:this.data.fullName_eng}),""!==this.data.fullName_eng&&ma.navigateTo({url:"../profile/profile"})}})},onShow(){t.onLocaleChange((a=>{e=a,this.setData({sign_in_with_telebirr:t.t("Sign In With Telebirr"),enter_fayda_no_text:t.t("Enter Your Unique Fayda ID Number (FIN)"),lost_fin:t.t("Lost Your FIN?"),next:t.t("Next"),greetings:t.t("Hello")})})),t.getLocale(),this.setData({sign_in_with_telebirr:t.t("Sign In With Telebirr"),enter_fayda_no_text:t.t("Enter Your Unique Fayda ID Number (FIN)"),lost_fin:t.t("Lost Your FIN?"),next:t.t("Next"),greetings:t.t("Hello")})},onHide(){},onUnload(){},onShareAppMessage:()=>({title:""})});
});
define("pages/lost_uin/lost_uin.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
t=getI18nInstance(),Page({data:{fronts:"",src:"../../images/giphy.gif",inputValue:"",baseUrl:"https://mobile-mini.fayda.et",accessToken:{access_token:"",token_type:"",refresh_token:""},rid_input:"",scan_qr_code:"",rid_required:"",please_scan_the_qr_code:"",enter_rid:"",resend_fin:"",failed:!1},bindInput:function(e){if("detail"in e){const a=e.detail.value.length;var t=e.detail.value;return(5!==a&&10!==a&&15!==a&&20!==a&&25!==a&&30!==a||"-"!==t.charAt(a-1)&&(t=t.slice(0,a-1)+"-"+t.charAt(a-1)),35===a&&(t=t.slice(0,4)+"-"+t.slice(5,9)+"-"+t.slice(10,14)+"-"+t.slice(15,19)+"-"+t.slice(20,24)+"-"+t.slice(25,29)+"-"+t.slice(30,35)),this.setData({rid_input:t}),t)}return 29==e.result.length?t=e.result.slice(0,4)+"-"+e.result.slice(4,8)+"-"+e.result.slice(8,12)+"-"+e.result.slice(12,16)+"-"+e.result.slice(16,20)+"-"+e.result.slice(20,24)+"-"+e.result.slice(24,32):ma.showModal({title:"QRCode Reading Error",content:"Make sure you scan the QR code which you will find on the registration confirmation paper.",showCancel:!1,confirmText:"Close",success(e){e.confirm||e.cancel}}),this.setData({rid_input:t}),e.result},resend_sms:function(e){faydaRID=e.detail.value.rid,faydaRID.includes("-")?faydaRID=faydaRID.replace(/-/g,""):faydaRID.includes(" ")&&(faydaRID=faydaRID.replace(/\s/g,""));var a=this;if(a.setData({loading_next:!0}),access_tokendic=this.data.accessToken,num_str=faydaRID.toString(),payload={senderId:"telebirr-app",regId:"10001100200037720220216085104"},29!=faydaRID.toString().length)return a.setData({loading_next:!1,failed_input:!0}),void ma.showModal({title:t.t("invalid_rid"),content:t.t("invalid_rid_content"),showCancel:!1,confirmText:"Close",success(e){e.confirm?a.setData({loading_next:!1,failed_input:!1,failed200:!1,failed444:!1,failed503:!1,failed_all:!1,success200:!1}):e.cancel}});try{jsonData=JSON.stringify(payload),access_tokendic=this.data.accessToken,ma.request({url:this.data.baseUrl+`/smsResend?rid=${num_str}`,method:"GET",header:{"Content-Type":"application/json",Authorization:"Bearer "+access_tokendic.access_token,"Refresh-Token":access_tokendic.refresh_token},timeout:5e5,success:e=>(a.setData({loading_next:!1}),JSON.stringify(e).includes("444")?(a.setData({loading_next:!1,failed444:!0}),void ma.showModal({title:t.t("444_resend"),content:t.t("444_resend_content"),confirmText:"Help",cancelText:"Cancel",success(e){if(e.confirm)return ma.openUrl({url:"https://www.id.gov.et/help"}),void a.setData({loading_next:!1,failed_input:!1,failed200:!1,failed444:!1,failed503:!1,failed_all:!1,success200:!1});e.cancel}})):JSON.stringify(e).includes('"statusCode":200')?(a.setData({loading_next:!1,success200:!0}),void ma.showModal({title:t.t("200_resend"),content:t.t("200_resend_content"),confirmText:"Close",showCancel:!1,success(e){e.confirm?a.setData({loading_next:!1,failed_input:!1,failed200:!1,failed444:!1,failed503:!1,failed_all:!1,success200:!1}):e.cancel}})):JSON.stringify(e).includes('"statusCode":503')?(a.setData({loading_next:!1,failed503:!0}),void ma.showModal({title:t.t("503_resend"),content:t.t("503_resend_content"),confirmText:"Close",showCancel:!1})):(a.setData({loading_next:!1,failed_all:!0}),void ma.showModal({title:t.t("error_resend"),content:t.t("error_resend_content"),confirmText:"Close",showCancel:!1,success(e){e.confirm?a.setData({loading_next:!1,failed_input:!1,failed200:!1,failed444:!1,failed503:!1,failed_all:!1,success200:!1}):e.cancel}}))),fail:e=>(this.setData({loading_next:!1}),JSON.stringify(e).includes("444")?(a.setData({loading_next:!1,failed444:!0}),void ma.showModal({title:t.t("444_resend"),content:t.t("444_resend_content"),confirmText:"Help",cancelText:"Cancel",success(e){if(e.confirm)return ma.openUrl({url:"https://www.id.gov.et/help"}),void a.setData({loading_next:!1,failed_input:!1,failed200:!1,failed444:!1,failed503:!1,failed_all:!1,success200:!1});e.cancel}})):JSON.stringify(e).includes("200")?(a.setData({loading_next:!1,successe200:!0}),void ma.showModal({title:t.t("200_resend"),content:t.t("200_resend_content"),confirmText:"Close",showCancel:!1,success(e){e.confirm?a.setData({loading_next:!1,failed_input:!1,failed200:!1,failed444:!1,failed503:!1,failed_all:!1,success200:!1}):e.cancel}})):JSON.stringify(e).includes("503")?(a.setData({loading_next:!1,failed503:!0}),void ma.showModal({title:t.t("503_resend"),content:t.t("503_resend_content"),confirmText:"Close",showCancel:!1,success(e){e.confirm?a.setData({loading_next:!1,failed_input:!1,failed200:!1,failed444:!1,failed503:!1,failed_all:!1,success200:!1}):e.cancel}})):(a.setData({loading_next:!1,failed_all:!0}),void ma.showModal({title:t.t("error_resend"),content:t.t("error_resend_content"),confirmText:"Close",showCancel:!1,success(e){e.confirm?a.setData({loading_next:!1,failed_input:!1,failed200:!1,failed444:!1,failed503:!1,failed_all:!1,success200:!1}):e.cancel}})))})}catch(s){a.setData({loading_next:!1}),ma.showModal({title:"Service not available, Please try again",content:"It seems like there is a connection error",confirmText:"Close",showCancel:!1,success(e){e.confirm?a.setData({loading_next:!1,failed_input:!1,failed200:!1,failed444:!1,failed503:!1,failed_all:!1,success200:!1}):e.cancel}})}},scanCode:function(){ma.scanCode({success:async e=>e.result.includes(":")?(clean=e.result.replace(/\s+/g,""),ridSplit=clean.split(":"),rid=ridSplit[1],result=this.bindInput({result:rid}),result):(result=this.bindInput(e),result),fail(e){this.setData({result:e.errMsg})},complete(e){this.setData({complete:"Completed"})}})},onLoad(e){ma.getStorage({key:"access_token",success(e){this.data.accessToken=e.data,this.setData({accessToken:this.data.accessToken})}})},onShow(){ma.getStorage({key:"access_token",success(e){this.data.accessToken=e.data,this.setData({accessToken:this.data.accessToken})}}),"en-US"===t.getLocale()?this.setData({scan_qr_code:"Scan QR Code",rid_required:"Your Registration ID is required!",please_scan_the_qr_code:"Please scan the QR code ",enter_rid:"Or, Enter your Registration number below",resend_fin:"Resend FIN"}):this.setData({scan_qr_code:"ኪው አር ኮድ ለማንሳት",rid_required:"የእርስዎ ምዝገባ መታወቂያ ቁጥር ያስፈልጋል!",please_scan_the_qr_code:"እባክዎ በምዝገባ ማረጋገጫ ቅጽ ላይ የሚገኘውን ኪው አር ኮድን ይቃኙ",enter_rid:"ወይም የምዝገባ ቁጥርዎን ከዚህ በታች ያስገቡ",resend_fin:"ልዩ ቁጥርዎን ለመላክ"})}});
});
define("pages/profile/profile.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
const t=getI18nInstance();Page({data:{locale:"am-ET",fullName:"",fullName_amh:"",verified:!0,src:"../../images/pr.png",image:"../../images/profile_img.png",QRCodes:"../../images/qr_code.png"},clickButton:function(){ma.navigateTo({url:"../id_front/id_front"})},detail:function(){ma.navigateTo({url:"../detail/detail"})},toggleLocale:function(){t.setLocale("am-ET"===t.getLocale()?"en-US":"am-ET"),ma.setStorage({key:"locale",data:t.getLocale()})},logout(){ma.showModal({title:t.t("alert_logout"),confirmText:t.t("yes"),cancelText:t.t("no"),success(a){if(a.confirm)ma.clearStorage({success:a=>{this.setData({key:"",data:""}),ma.reLaunch({url:"../index/index"}),ma.showModal({title:"You have logged out successfully!",cancelText:False,confirmText:"Okay"})},fail(a){ma.showToast({title:"FAILED",icon:"error",duration:2e3})}});else if(a.cancel)return},fail(){}})},async onShow(a){await ma.getStorage({key:"data",success(a){this.data.fullName=a.data.data.data.fullName_eng,this.data.fullName_amh=a.data.data.data.fullName_amh,this.data.QRCodes="data:image/png;base64, "+a.data.data.data.QRCodes,this.data.image="data:image/png;base64, "+a.data.data.data.photo,this.setData({fullName:this.data.fullName,fullName_amh:this.data.fullName_amh,image:this.data.image,QRCodes:this.data.QRCodes})}})},onReady(){ma.getStorage({key:"locale",success(a){this.data.locale=a.data,this.setData({locale:this.data.locale})}}),t.setLocale(this.data.locale)}});
});
define("pages/qrcode/qrcode.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
t=getI18nInstance(),Page({data:{locale:"am-ET",title:"Tap on Scan QR Code to Verify an ID",verified:!1,result:"",split_string:"",complete:"",decodedqrcodefromsign:"",photo:"../../images/qr_code.png",signature:"",fullName:"",fcn:"",dob:"",gender:"",version:"",faydacert:"-----BEGIN CERTIFICATE-----\nMIIDlzCCAn+gAwIBAgIICe/UHy0O2hUwDQYJKoZIhvcNAQELBQAwbjELMAkGA1UE\nBhMCSU4xCzAJBgNVBAgMAktBMRIwEAYDVQQHDAlCQU5HQUxPUkUxDTALBgNVBAoM\nBElJVEIxGjAYBgNVBAsMEU1PU0lQLVRFQ0gtQ0VOVEVSMRMwEQYDVQQDDApNT1NJ\nUC1ST09UMB4XDTIxMDUyNTA2MzcyN1oXDTI0MDUyNDA2MzcyN1owdTELMAkGA1UE\nBhMCSU4xCzAJBgNVBAgMAktBMRIwEAYDVQQHDAlCQU5HQUxPUkUxDTALBgNVBAoM\nBElJVEIxGjAYBgNVBAsMEU1PU0lQLVRFQ0gtQ0VOVEVSMRowGAYDVQQDDBFNT1NJ\nUC1LRVJORUwtU0lHTjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOUM\nIgr1qel0RRKq/YZGfvp717MmfCDr11/qXlmBRZML0tMKwJQYzRh+nMVgEaB8o4Vt\nMmYo6ztpZ4gbFHrsy4mirml8kOcTKGKkamQfdPZdim3ZhvCdvzUl/BVOCBJB1/Y0\nBy8n+M9qrDWEbtQr8DiDKJ3FuIvoxBTd+0l3Nt/m8xGihTCkdMzC1m5mZPIIgmwx\n9ZVa1zUiSNilaC6HAzCAg9UixveYsNwmMF1rD0qFULExWEJA6sKsqzQTpqOKEOol\n3hl7no2TS1rfAbXVb9uCo1+mwx7WgN9SJ871zDYFOXGaTRVpPlKuRePIJPc/eoKy\nZ9ntjXF0dKVvo6dK/B8CAwEAAaMyMDAwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4E\nFgQU9rAe48NpeiNBQoLLpmaW1cWuEaMwDQYJKoZIhvcNAQELBQADggEBAOQJbGax\ngH9VuyxR0SByYq70fq51Im75tp8e3CXSHKNOALZskuhGOv2JL/3pA4k9aTZ7RGQm\nvGAh9rGsL+Ph9ijLmgrdduK00x8TXX1tUL9g/dJlYbWI7mFAXGZylIEuTSMZ9/c7\nG+2yZzr/7PQFceU+nqdQ6021Bp0uTcdZON7jkI8AXhZAebENCZRoNNIStiFjuCEa\nrbMU6oHQCQEoAv6Uh5UARC8u5UrV0SleuN08abruMVpGAJrBW/CEHumiudvN3e9C\nAC7Uxi/5CqvwT5O+CTyd+B3opNdrrQfw5cNKByAas4moGdZPG2Mx8J4XdqRwFva8\nwGJjke2hcKOzgQY=\n-----END CERTIFICATE-----\n",faydaPK:"-----BEGIN PUBLIC KEY-----\n    MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5QwiCvWp6XRFEqr9hkZ+\n    +nvXsyZ8IOvXX+peWYFFkwvS0wrAlBjNGH6cxWARoHyjhW0yZijrO2lniBsUeuzL\n    iaKuaXyQ5xMoYqRqZB909l2KbdmG8J2/NSX8FU4IEkHX9jQHLyf4z2qsNYRu1Cvw\n    OIMoncW4i+jEFN37SXc23+bzEaKFMKR0zMLWbmZk8giCbDH1lVrXNSJI2KVoLocD\n    MICD1SLG95iw3CYwXWsPSoVQsTFYQkDqwqyrNBOmo4oQ6iXeGXuejZNLWt8BtdVv\n    24KjX6bDHtaA31InzvXMNgU5cZpNFWk+Uq5F48gk9z96grJn2e2NcXR0pW+jp0r8\n    HwIDAQAB\n    -----END PUBLIC KEY-----",faydaPK2:"-----BEGIN PUBLIC KEY-----\n    MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0L0yxop/NwMRrUl2ThfZ\n    NjS84euK7BMHLlrZ+MbnTneBeSDy/1dJbrxTaChW6S4W4bA9VvfR0YSk7s0Rq17l\n    AQ/UkaUuVbTSLXzGJUicGI6eFWpp0WYuDz0y0lEQQL0+LgAb+4AsilVyNBnvKTbn\n    Ai2jEiCRIZKELbWsbvreNePzDRvCn+CH8Vy0p4QcJ4fM1UHU+QFYrPOCvv997iVy\n    TnXlVO9hGV0IRFIhYRklBUFi3LvgJNVvCvQUO6tI27Y+HSBG8/XRxylO3it0iGws\n    fetX5ldF/9TdZ3zw+FZuOrUKt763V+2eyAz4vomH+HvfnEaBstaKI6V5OhFZCc62\n    uwIDAQAB\n    -----END PUBLIC KEY-----\n    ",complete:"",scan_qr_code:"",scan_qr_code_title:"",Verified:"",Not_verified:"",done:""},done:function(){this.setData({result:"",photo:"../../images/qr_code.png",signature:"",fullName:"",userinformation:"",split_string:"",complete:"",fcn:"",dob:""})},base64ToArrayBuffer:function(e){const t=atob(e.replace(/\s+/g,"")).length,i=new Uint8Array(t);for(let s=0;s<t;s++)i[s]=e.charCodeAt(s);return i.buffer},importPublicKey:function(e){const t=this.base64ToArrayBuffer(e);return crypto.subtle.importKey("pkcs8",t,{name:"RSA-PSS",hash:{name:"SHA-256"}},!0,["verify"])},base64UrlEncode:function(e){let t=btoa(e);return(t=t.replace(/\+/g,"-").replace(/\//g,"_"),t=t.replace(/=+$/,""),t)},pemToCryptoKey:async function(e){const t=e.replace(/-----BEGIN PUBLIC KEY-----/,"").replace(/-----END PUBLIC KEY-----/,"").replace(/\s+/g,""),i=Uint8Array.from(atob(t),(e=>e.charCodeAt(0)));return await crypto.subtle.importKey("spki",i,{name:"RSASSA-PKCS1-v1_5",hash:{name:"SHA-256"}},!0,["verify"])},verifySignature:async function(e,t,i){[headerSplit,payloadSplit,signatureSplit]=e.split("."),payload_base_64=this.base64UrlEncode(i),data=`${headerSplit}.${payload_base_64}`;const s=(new TextEncoder).encode(data);signature=signatureSplit+"==",signature_to_base64=atob(signature.replace(/-/g,"+").replace(/_/g,"/")),decoded_signature=Uint8Array.from(signature_to_base64,(e=>e.charCodeAt(0))),key=await this.pemToCryptoKey(t);return await crypto.subtle.verify({name:"RSASSA-PKCS1-v1_5",hash:"SHA-256"},key,decoded_signature,s)},scanCode:function(){ma.scanCode({success:async e=>{if(e.result.includes("SIGN")){this.data.split_string=e.result.split(":DLT:"),encodedString=encodeURIComponent(e.result.split(":SIGN:")[0].split(":DLT:")[1]),splited_sign_dlt=e.result.split(":SIGN:")[0].split(":DLT:")[1];let t;userphoto=e.result.split(":SIGN:")[0].split(":DLT:")[0],base64photo=userphoto.replace(/-/g,"+").replace(/_/g,"/"),t=-1!==splited_sign_dlt.indexOf("?"),excludequestionmark=t?splited_sign_dlt.split("?"):[splited_sign_dlt],payload_user=e.result.split(":SIGN:")[0],payload_user.includes(":V:")?(split1=payload_user.split(":V:")[1],split3=payload_user.split(":V:")[0],fullname_=split3.split(":DLT:")[1],split4=split1.split(":A:")[0],version_=split4.split(":G:")[0],gender_=split4.split(":G:")[1],"2"==version_&&(split2=split1.split(":A:")[1],fcn_=split2.split(":D:")[0],dob_=split2.split(":D:")[1],this.setData({result:e.result,photo:"data:image/png;base64, "+base64photo,signature:e.result.split(":SIGN:")[1],fullName:fullname_,fcn:fcn_,dob:dob_,gender:gender_,version:version_,userinformation:e.result.split(":SIGN:")[0],split_string:e.result.split(":SIGN:")[0].split(":DLT:")[1],complete:"Completed",faydaPK:"-----BEGIN PUBLIC KEY-----\n                MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5QwiCvWp6XRFEqr9hkZ+\n                +nvXsyZ8IOvXX+peWYFFkwvS0wrAlBjNGH6cxWARoHyjhW0yZijrO2lniBsUeuzL\n                iaKuaXyQ5xMoYqRqZB909l2KbdmG8J2/NSX8FU4IEkHX9jQHLyf4z2qsNYRu1Cvw\n                OIMoncW4i+jEFN37SXc23+bzEaKFMKR0zMLWbmZk8giCbDH1lVrXNSJI2KVoLocD\n                MICD1SLG95iw3CYwXWsPSoVQsTFYQkDqwqyrNBOmo4oQ6iXeGXuejZNLWt8BtdVv\n                24KjX6bDHtaA31InzvXMNgU5cZpNFWk+Uq5F48gk9z96grJn2e2NcXR0pW+jp0r8\n                HwIDAQAB\n                -----END PUBLIC KEY-----"})),"3"==version_&&(split2=split1.split(":A:")[1],fcn_=split2.split(":D:")[0],dob_=split2.split(":D:")[1],this.setData({result:e.result,photo:"data:image/png;base64, "+base64photo,signature:e.result.split(":SIGN:")[1],fullName:fullname_,fcn:fcn_,dob:dob_,gender:gender_,version:version_,userinformation:e.result.split(":SIGN:")[0],split_string:e.result.split(":SIGN:")[0].split(":DLT:")[1],complete:"Completed",faydaPK:this.data.faydaPK2}))):this.setData({result:e.result,photo:"data:image/png;base64, "+base64photo,signature:e.result.split(":SIGN:")[1],fullName:excludequestionmark[0],userinformation:e.result.split(":SIGN:")[0],split_string:e.result.split(":SIGN:")[0].split(":DLT:")[1],complete:"Completed",faydaPK:"-----BEGIN PUBLIC KEY-----\n              MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA5QwiCvWp6XRFEqr9hkZ+\n              +nvXsyZ8IOvXX+peWYFFkwvS0wrAlBjNGH6cxWARoHyjhW0yZijrO2lniBsUeuzL\n              iaKuaXyQ5xMoYqRqZB909l2KbdmG8J2/NSX8FU4IEkHX9jQHLyf4z2qsNYRu1Cvw\n              OIMoncW4i+jEFN37SXc23+bzEaKFMKR0zMLWbmZk8giCbDH1lVrXNSJI2KVoLocD\n              MICD1SLG95iw3CYwXWsPSoVQsTFYQkDqwqyrNBOmo4oQ6iXeGXuejZNLWt8BtdVv\n              24KjX6bDHtaA31InzvXMNgU5cZpNFWk+Uq5F48gk9z96grJn2e2NcXR0pW+jp0r8\n              HwIDAQAB\n              -----END PUBLIC KEY-----"}),originalData=this.data.userinformation,signature_org=this.data.signature,isSIGNVerified=await this.verifySignature(signature_org,this.data.faydaPK,originalData),!0===isSIGNVerified?verified=!0:verified=!1,this.setData({verified:isSIGNVerified})}else this.setData({verified:!1})},fail(e){this.setData({result:e.errMsg})},complete(e){this.setData({complete:"Completed"})}})},onShow(){"en-US"===t.getLocale()?this.setData({scan_qr_code:"Scan QR Code",scan_qr_code_title:"Tap on Scan QR Code to Verify an ID",Not_verified:"Not Verified",Verified:"Verified",done:"Done"}):this.setData({scan_qr_code:"ኪው አር ኮድ ለማንሳት",scan_qr_code_title:"አንድን መታወቂያ ለማረጋገጥ ኪው አር ኮድ ለማንሳት የሚለውን ይጫኑ።",Not_verified:"ትክክለኛነቱ ያልተረጋገጠ",Verified:"ትክክለኛነቱ የተረጋገጠ",done:"እሺ"})},onReady(){},onLoad(e){}});
});
define("pages/registration/registration.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit){
Page({openLink:function(){ma.openUrl({url:"https://register.fayda.et"})},onLoad:function(n){},onReady:function(){},onShow:function(){},onHide:function(){},onUnload:function(){},onPullDownRefresh:function(){},onShareAppMessage:function(){},onPageScroll:function(){}});
});
__maRoute='app';require("app.js");
__maRoute='pages/detail/detail';require("pages/detail/detail.js");
__maRoute='pages/id_back/id_back';require("pages/id_back/id_back.js");
__maRoute='pages/id_front/id_front';require("pages/id_front/id_front.js");
__maRoute='pages/index/index';require("pages/index/index.js");
__maRoute='pages/lost_uin/lost_uin';require("pages/lost_uin/lost_uin.js");
__maRoute='pages/profile/profile';require("pages/profile/profile.js");
__maRoute='pages/qrcode/qrcode';require("pages/qrcode/qrcode.js");
__maRoute='pages/registration/registration';require("pages/registration/registration.js");
